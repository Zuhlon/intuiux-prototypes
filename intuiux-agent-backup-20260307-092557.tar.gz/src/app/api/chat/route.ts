import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

const AGENT_PROMPTS: Record<string, string> = {
  transcription_analyst: `Ты — эксперт по анализу идей продуктов. 
КРИТИЧЕСКИ ВАЖНО: Анализируй КОНКРЕТНЫЙ текст пользователя. 
- НЕ используй шаблоны интернет-магазина
- НЕ придумывай абстрактные продукты
- Извлекай идею ТОЛЬКО из предоставленного текста
Отвечай на русском языке.`,
  
  brand_marketer: `Ты — маркетолог с 15-летним опытом конкурентного анализа.
КРИТИЧЕСКИ ВАЖНО: 
- Анализируй КОНКРЕТНУЮ идею из раздела "СФОРМИРОВАННАЯ ИДЕЯ ПРОДУКТА"
- НЕ используй шаблоны интернет-магазина
- Ищи РЕАЛЬНЫХ конкурентов для этого типа продукта
- Если в идее указан конкретный продукт (например, "приложение для поиска попутчиков"), ищи конкурентов ИМЕННО в этой нише
Отвечай на русском языке.`,
  
  cjm_researcher: `Ты — исследователь Customer Journey Map.
КРИТИЧЕСКИ ВАЖНО:
- Создавай CJM ТОЛЬКО для продукта из раздела "СФОРМИРОВАННАЯ ИДЕЯ ПРОДУКТА"
- НЕ используй шаблоны интернет-магазина
- Этапы пути должны отражать КОНКРЕТНЫЕ функции этого продукта
- Используй Mermaid journey для визуализации
Отвечай на русском языке.`,
  
  ia_architect: `Ты — архитектор информационной архитектуры.
КРИТИЧЕСКИ ВАЖНО:
- Создавай ИА ТОЛЬКО для продукта из раздела "СФОРМИРОВАННАЯ ИДЕЯ ПРОДУКТА"
- НЕ используй шаблоны интернет-магазина
- Сущности и разделы должны отражать КОНКРЕТНЫЕ функции этого продукта
- Используй Mermaid mindmap и erDiagram
Отвечай на русском языке.`,
  
  task_architect: `Ты — специалист по юзабилити-тестированию.
КРИТИЧЕСКИ ВАЖНО:
- Создавай материалы ТОЛЬКО для продукта из раздела "СФОРМИРОВАННАЯ ИДЕЯ ПРОДУКТА"
- НЕ используй шаблоны интернет-магазина
- Задачи и вопросы должны относиться к КОНКРЕТНЫМ функциям этого продукта
Отвечай на русском языке.`,
  
  prototyper: `Ты — прототипировщик интерактивных HTML приложений в стиле Taiga (https://taiga-landing.vercel.app/).

═══════════════════════════════════════════════════════════════
🎯 КОНТЕКСТНАЯ ГЕНЕРАЦИЯ (КРИТИЧЕСКИ ВАЖНО)
═══════════════════════════════════════════════════════════════

Ты должен создать прототип на основе ВСЕХ предыдущих этапов:

1. **ИЗ ИДЕИ** возьми:
   - Название продукта
   - Описание сути проблемы
   - Целевую аудиторию
   - Ключевые функции (максимум 5)

2. **ИЗ КОНКУРЕНТОВ** возьми:
   - Уникальное преимущество (дифференциация)
   - Функции, которых нет у конкурентов

3. **ИЗ CJM** возьми:
   - Ключевые точки касания
   - Эмоциональное состояние пользователя
   - Pain points для решения

4. **ИЗ IA** возьми:
   - Структуру разделов приложения
   - Ключевые сущности

5. **ИЗ USERFLOW** возьми:
   - Последовательность экранов
   - Переходы между шагами
   - Ключевые действия пользователя

═══════════════════════════════════════════════════════════════
🎨 ДИЗАЙН-СИСТЕМА TAIGA
═══════════════════════════════════════════════════════════════

Цвета:
- Фон: #000000, #0A0A0A, #141414
- Акцент: #FACC15 (жёлтый) — кнопки, иконки, важные метрики
- Текст: #FFFFFF (основной), #A3A3A3 (вторичный), #737373 (muted)
- Success: #22C55E, Error: #EF4444

Шрифты:
- Inter — для всего текста
- JetBrains Mono — для цифр и кода

Анимации (CSS keyframes):
- float: translateY для парящих элементов
- glow: box-shadow для свечения
- shimmer: background-position для мерцания текста
- pulse: scale для пульсации
- scanline: translateY для линии сканирования

Эффекты:
- Backdrop blur на header
- Card glow при hover
- Grid background
- Gradient text

═══════════════════════════════════════════════════════════════
📱 СТРУКТУРА ПРИЛОЖЕНИЯ (адаптируй под Userflow!)
═══════════════════════════════════════════════════════════════

Реализуй многоэкранное приложение с навигацией через showScreen(id):

1. **SPLASH/HERO экран** 
   - Логотип продукта (первые буквы названия)
   - Название из Идеи
   - Value proposition из Идеи
   - CTA кнопка "Начать"

2. **ONBOARDING** (2-3 шага)
   - Знакомство с ключевыми функциями из Идеи
   - Прогресс-бар
   - Кнопки "Далее/Пропустить"

3. **ГЛАВНЫЙ ЭКРАН (Dashboard)**
   - Header с навигацией
   - Виджеты с метриками (из Идеи и CJM)
   - Быстрые действия (функции из Идеи)
   - Bottom navigation

4. **ЭКРАНЫ ФУНКЦИЙ** (для каждого ключевого действия из Userflow)
   - Формы ввода данных
   - Кнопки действий
   - Отображение результатов
   - Навигация "Назад"

5. **РЕЗУЛЬТАТ/УСПЕХ**
   - Подтверждение действия
   - Иконка успеха
   - Кнопки "На главную/Новое действие"

6. **ПРОФИЛЬ/НАСТРОЙКИ**
   - Информация пользователя
   - Настройки приложения
   - Выход

═══════════════════════════════════════════════════════════════
🔧 ТЕХНИЧЕСКИЕ ТРЕБОВАНИЯ
═══════════════════════════════════════════════════════════════

JavaScript функции:
- showScreen(id) — переключение экранов
- showTab(tabId) — переключение вкладок
- showToast(message) — уведомления

Формат:
- Полный HTML в одном блоке
- CSS в <style>
- JavaScript в <script>
- Google Fonts: Inter, JetBrains Mono

ВАЖНО:
- НЕ создавай landing page — создай ИНТЕРАКТИВНОЕ ПРИЛОЖЕНИЕ
- Каждый экран должен отражать КОНКРЕТНЫЙ контекст из Идеи
- Названия кнопок, заголовков — из Идеи и Userflow`
};

// === HELPER FUNCTIONS FOR AUTO-DEPLOYMENT ===

// Transliterate Russian to English for URL slug
function transliterateToSlug(text: string): string {
  const ruToEn: Record<string, string> = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo',
    'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
    'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
    'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'sch',
    'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya',
    'А': 'a', 'Б': 'b', 'В': 'v', 'Г': 'g', 'Д': 'd', 'Е': 'e', 'Ё': 'yo',
    'Ж': 'zh', 'З': 'z', 'И': 'i', 'Й': 'y', 'К': 'k', 'Л': 'l', 'М': 'm',
    'Н': 'n', 'О': 'o', 'П': 'p', 'Р': 'r', 'С': 's', 'Т': 't', 'У': 'u',
    'Ф': 'f', 'Х': 'kh', 'Ц': 'ts', 'Ч': 'ch', 'Ш': 'sh', 'Щ': 'sch',
    'Ъ': '', 'Ы': 'y', 'Ь': '', 'Э': 'e', 'Ю': 'yu', 'Я': 'ya',
    ' ': '-', '_': '-', '/': '-', '\\': '-'
  };
  
  // Transliterate first, then clean up
  let slug = text
    .split('')
    .map(char => ruToEn[char] ?? char)
    .join('')
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, '') // Keep only latin letters, numbers, and dashes
    .replace(/-+/g, '-') // Replace multiple dashes
    .replace(/^-|-$/g, '') // Trim dashes
    .substring(0, 50); // Limit length
  
  const randomSuffix = Math.random().toString(36).substring(2, 8);
  return `${slug}-${randomSuffix}`;
}

// Extract product name from message or response
function extractProductName(message: string, response: string): string {
  // Try to find name in the response header
  const headerMatch = response.match(/## 🎨 Интерактивный прототип "?([^"\n]+)"?/);
  if (headerMatch && headerMatch[1]) {
    return headerMatch[1].trim();
  }
  
  // Try to find name in the message
  const ideaMatch = message.match(/Название идеи[^*]*\*\*([^*]+)\*\*/);
  if (ideaMatch && ideaMatch[1]) {
    return ideaMatch[1].trim();
  }
  
  // Try to find in ## 💡 section
  const nameMatch = message.match(/## 💡\s*Название идеи\s*\n\*?\*?([^*\n]+)/);
  if (nameMatch && nameMatch[1]) {
    return nameMatch[1].trim();
  }
  
  return 'Prototype';
}

// Check accessibility
function checkAccessibility(html: string): { score: number; issues: string[] } {
  const issues: string[] = [];
  let score = 100;
  
  const imgMatches = html.match(/<img[^>]*>/gi) || [];
  const imgWithoutAlt = imgMatches.filter(img => !img.includes('alt='));
  if (imgWithoutAlt.length > 0) {
    issues.push(`Images without alt: ${imgWithoutAlt.length}`);
    score -= 10 * imgWithoutAlt.length;
  }
  
  if (!html.includes('<main') && !html.includes('role="main"')) {
    issues.push('Missing <main> element');
    score -= 5;
  }
  
  if (!html.includes('<header') && !html.includes('role="banner"')) {
    issues.push('Missing <header> element');
    score -= 5;
  }
  
  if (!html.includes('<nav') && !html.includes('role="navigation"')) {
    issues.push('Missing <nav> element');
    score -= 5;
  }
  
  if (!html.includes('lang=')) {
    issues.push('Missing lang attribute');
    score -= 5;
  }
  
  if (!html.includes('<title>')) {
    issues.push('Missing <title>');
    score -= 10;
  }
  
  if (!html.includes('viewport')) {
    issues.push('Missing viewport');
    score -= 5;
  }
  
  return { score: Math.max(0, Math.min(100, score)), issues };
}

// Deploy prototype to database
async function deployPrototype(productName: string, htmlContent: string): Promise<{
  success: boolean;
  deployment?: {
    id: string;
    productName: string;
    slug: string;
    url: string;
    accessibilityScore: number;
    accessibilityIssues: string[];
  };
  error?: string;
}> {
  try {
    // Extract HTML from markdown code block
    const htmlMatch = htmlContent.match(/```html\s*([\s\S]*?)```/);
    const cleanHtml = htmlMatch && htmlMatch[1] ? htmlMatch[1].trim() : htmlContent;
    
    const slug = transliterateToSlug(productName);
    const accessibility = checkAccessibility(cleanHtml);
    
    const deployment = await db.prototypeDeployment.create({
      data: {
        productName,
        slug,
        htmlContent: cleanHtml,
        accessibilityScore: accessibility.score,
        accessibilityIssues: JSON.stringify(accessibility.issues),
        status: 'deployed',
        vercelUrl: `/api/prototype/${slug}`,
        deployedAt: new Date()
      }
    });
    
    return {
      success: true,
      deployment: {
        id: deployment.id,
        productName: deployment.productName,
        slug: deployment.slug,
        url: deployment.vercelUrl || `/api/prototype/${deployment.slug}`,
        accessibilityScore: accessibility.score,
        accessibilityIssues: accessibility.issues
      }
    };
  } catch (error) {
    console.error('Deploy prototype error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to deploy'
    };
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    const body = await request.json();
    const { agentId, agentType, message, conversationId } = body;
    
    let actualAgentType = agentType;
    let agent = null;
    
    if (agentId && !agentType) {
      agent = await db.agent.findUnique({ where: { id: agentId } });
      if (agent) {
        actualAgentType = agent.type;
      }
    }
    
    if (!message) {
      return NextResponse.json({ success: false, error: 'Message is required' }, { status: 400 });
    }
    
    let conversation;
    const effectiveAgentId = agentId || `pipeline-${actualAgentType}`;
    
    const existingAgent = await db.agent.findUnique({ where: { id: effectiveAgentId } });
    const saveToDb = !!existingAgent;
    
    if (saveToDb) {
      if (conversationId) {
        conversation = await db.conversation.findUnique({ where: { id: conversationId } });
      }
      if (!conversation) {
        conversation = await db.conversation.create({
          data: { agentId: effectiveAgentId, title: message.substring(0, 50) }
        });
      }
    }
    
    if (saveToDb && conversation) {
      await db.message.create({
        data: { conversationId: conversation.id, role: 'user', content: message }
      });
    }
    
    const systemPrompt = AGENT_PROMPTS[actualAgentType] || `Ты — AI-ассистент. Помогай пользователю.`;
    
    let aiResponse = '';
    
    try {
      const zai = await getZAI();
      
      const messages = [
        { role: 'assistant' as const, content: systemPrompt },
        { role: 'user' as const, content: message }
      ];
      
      const timeoutPromise = new Promise<null>((_, reject) => {
        setTimeout(() => reject(new Error('Timeout')), 30000);
      });
      
      const completionPromise = zai.chat.completions.create({
        messages,
        thinking: { type: 'disabled' }
      });
      
      const completion = await Promise.race([completionPromise, timeoutPromise]);
      
      if (completion && completion.choices && completion.choices[0]) {
        aiResponse = completion.choices[0].message?.content || '';
      }
      
      console.log(`AI response time for ${actualAgentType}: ${Date.now() - startTime}ms`);
      
    } catch (aiError) {
      console.log(`AI timeout/error after ${Date.now() - startTime}ms, using fallback`);
      aiResponse = getFallbackResponse(actualAgentType, message);
    }
    
    if (!aiResponse || aiResponse.trim().length === 0) {
      aiResponse = getFallbackResponse(actualAgentType, message);
    }
    
    if (saveToDb && conversation) {
      await db.message.create({
        data: { conversationId: conversation.id, role: 'assistant', content: aiResponse }
      });
    }
    
    // Auto-deploy prototype after generation
    let deploymentInfo = null;
    if (actualAgentType === 'prototyper' && aiResponse.includes('```html')) {
      try {
        const productName = extractProductName(message, aiResponse);
        const deploymentResult = await deployPrototype(productName, aiResponse);
        if (deploymentResult.success) {
          deploymentInfo = deploymentResult.deployment;
          console.log(`[Auto-deploy] Prototype deployed: ${deploymentInfo.url}`);
          // Add deployment link to response
          aiResponse += `\n\n---\n\n## 🚀 Прототип развёрнут\n\n**Ссылка на прототип:** [${deploymentInfo.url}](${deploymentInfo.url})\n\n**Оценка доступности:** ${deploymentInfo.accessibilityScore}/100\n\n${deploymentInfo.accessibilityIssues.length > 0 ? `**Замечания по доступности:**\n${deploymentInfo.accessibilityIssues.map((i: string) => `- ${i}`).join('\n')}` : '✅ Все основные проверки доступности пройдены'}`;
        }
      } catch (deployError) {
        console.error('[Auto-deploy] Failed:', deployError);
      }
    }
    
    return NextResponse.json({
      success: true,
      response: aiResponse,
      conversationId: conversation?.id || null,
      deployment: deploymentInfo
    });
    
  } catch (error) {
    console.error('Error in chat:', error);
    return NextResponse.json({ success: false, error: 'Failed to process message' }, { status: 500 });
  }
}

// Extract idea from the message - improved version
function extractFormedIdea(message: string): { name: string; description: string; functions: string[] } {
  let ideaText = '';
  
  // Pattern 1: Section between separator lines with "СФОРМИРОВАННАЯ ИДЕЯ"
  const separatorMatch = message.match(/[═=]{5,}[^═=]*СФОРМИРОВАННАЯ ИДЕЯ ПРОДУКТА[\s\S]*?[═=]{5,}/i);
  if (separatorMatch) {
    ideaText = separatorMatch[0];
    console.log('[extractFormedIdea] Found via pattern 1 (separator section)');
  }
  
  // Pattern 2: Look for the content after "СФОРМИРОВАННАЯ ИДЕЯ ПРОДУКТА"
  if (!ideaText) {
    const ideaMatch = message.match(/СФОРМИРОВАННАЯ ИДЕЯ ПРОДУКТА[\s\S]*?(?=Предыдущий контекст|═══|===|$)/i);
    if (ideaMatch) {
      ideaText = ideaMatch[0];
      console.log('[extractFormedIdea] Found via pattern 2 (ИДЕЯ header)');
    }
  }
  
  // Pattern 3: Look for ## 💡 section
  if (!ideaText) {
    const ideaMatch = message.match(/## 💡[^\n]*[\s\S]*?(?=## \d|===|Предыдущий|$)/i);
    if (ideaMatch) {
      ideaText = ideaMatch[0];
      console.log('[extractFormedIdea] Found via pattern 3 (## 💡 header)');
    }
  }
  
  if (!ideaText) {
    ideaText = message.substring(0, 1500);
    console.log('[extractFormedIdea] Using fallback - first 1500 chars');
  }
  
  // Extract name - clean from markdown
  let name = 'Продукт';
  
  // Pattern: ## 💡 Название идеи\n**Name** or ## 💡 Название идеи\nName
  const nameLineMatch = ideaText.match(/## 💡\s*Название идеи\s*\n\*?\*?([^*\n]+)\*?\*?/i);
  if (nameLineMatch && nameLineMatch[1]) {
    const extracted = nameLineMatch[1].trim();
    if (extracted.length > 2) {
      name = extracted;
      console.log(`[extractFormedIdea] Found name via header: "${name}"`);
    }
  }
  
  // Try bold text after "Название идеи"
  if (name === 'Продукт') {
    const boldMatch = ideaText.match(/Название идеи[^\n]*\n\s*\*\*([^*]+)\*\*/i);
    if (boldMatch && boldMatch[1]) {
      name = boldMatch[1].trim();
      console.log(`[extractFormedIdea] Found name via bold: "${name}"`);
    }
  }
  
  // Clean name from markdown and extra characters
  name = name.replace(/\*\*/g, '').replace(/["«»]/g, '').trim();
  
  // Extract description
  let description = 'Инновационный продукт для решения задач пользователей';
  const descPatterns = [
    /(?:Описание сути|Описание)[^:]*:?\s*([^\n]+(?:\n[^\n#]+)*?)(?=\n###|\n##|$)/i,
  ];
  
  for (const pattern of descPatterns) {
    const match = ideaText.match(pattern);
    if (match && match[1]) {
      const extracted = match[1].trim().replace(/[═=*]/g, '').trim();
      if (extracted.length > 10) {
        description = extracted.substring(0, 200);
        break;
      }
    }
  }
  
  // Extract functions - properly from "Основные функции" section only
  const functions: string[] = [];
  
  // Pattern for "Основные функции" section
  const funcSectionMatch = ideaText.match(/(?:Основные функции|Функции)[^:]*:?\s*([\s\S]*?)(?=\n###|\n##|---|$)/i);
  if (funcSectionMatch && funcSectionMatch[1]) {
    const section = funcSectionMatch[1];
    // Match numbered items: 1. Function name
    const funcLines = section.match(/\d+\.\s+[^\n]+/g);
    if (funcLines) {
      funcLines.slice(0, 6).forEach(line => {
        const func = line.replace(/^\d+\.\s*/, '').replace(/\*\*/g, '').trim();
        // Filter out metrics (they contain "цель:", "—", etc.)
        if (func && func.length > 5 && !func.includes('цель:') && !func.includes('— цель')) {
          functions.push(func.substring(0, 80));
        }
      });
    }
  }
  
  // Default functions if none found
  if (functions.length === 0) {
    functions.push('Основная функция продукта');
    functions.push('Дополнительные возможности');
    functions.push('Настройки и профиль');
  }
  
  console.log(`[extractFormedIdea] Result - name: "${name}", functions: [${functions.slice(0, 2).join(', ')}...]`);
  
  return { name, description, functions };
}

// === PRODUCT TYPE DETECTION ===

interface ProductType {
  id: string;
  name: string;
  keywords: string[];
  marketSize: string;
  trends: string[];
  barriers: string[];
  positioning: string;
}

interface Competitor {
  name: string;
  url: string;
  country: string;
  description: string;
  features: string;
  pricing: string;
  targetAudience: string;
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
  functionalityScore: string;
  priceScore: string;
  uxScore: string;
  supportScore: string;
}

interface IndirectCompetitor {
  name: string;
  description: string;
  approach: string;
  overlap: string;
  differentiation: string;
}

// База знаний о типах продуктов и их конкурентах
const PRODUCT_TYPES: ProductType[] = [
  {
    id: 'ats',
    name: 'Виртуальная АТС / Телефония',
    keywords: ['атс', 'ats', 'телефон', 'звонок', 'call', 'ivr', 'голосовой', 'автоответчик', 'колл-центр', 'sip'],
    marketSize: '$15 млрд глобально, $500 млн в РФ (2024)',
    trends: ['Переход на облачные решения', 'Интеграция с CRM', 'AI-ассистенты для звонков', 'Омниканальность'],
    barriers: ['Интеграция с существующей инфраструктурой', 'Надёжность связи', 'Соблюдение законодательства'],
    positioning: 'современное решение для бизнеса с гибкими интеграциями'
  },
  {
    id: 'dashboard',
    name: 'Бизнес-дашборд / Аналитика',
    keywords: ['дашборд', 'dashboard', 'аналитик', 'метрик', 'отчёт', 'report', 'kpi', 'график', 'chart', 'bi-систем'],
    marketSize: '$25 млрд глобально (BI-рынок)',
    trends: ['Self-service аналитика', 'Real-time данные', 'AI-инсайты', 'Мобильные дашборды'],
    barriers: ['Качество данных', 'Сложность внедрения', 'Обучение пользователей'],
    positioning: 'интуитивный инструмент для принятия решений'
  },
  {
    id: 'crm',
    name: 'CRM-система',
    keywords: ['crm', 'клиент', 'customer', 'продаж', 'sales', 'лид', 'lead', 'сделк', 'deal'],
    marketSize: '$80 млрд глобально',
    trends: ['AI-прогнозирование продаж', 'Автоматизация процессов', 'Интеграция с мессенджерами'],
    barriers: ['Сопротивление сотрудников', 'Миграция данных', 'Сложность настройки'],
    positioning: 'простая CRM для малого и среднего бизнеса'
  },
  {
    id: 'ecommerce',
    name: 'E-commerce / Интернет-магазин',
    keywords: ['магазин', 'shop', 'ecommerce', 'торгов', 'заказ', 'order', 'корзин', 'cart', 'товар', 'product'],
    marketSize: '$6 трлн глобально',
    trends: ['Маркетплейсы', 'Social commerce', 'Персонализация', 'Быстрая доставка'],
    barriers: ['Логистика', 'Конкуренция', 'Обработка платежей'],
    positioning: 'современная платформа электронной коммерции'
  },
  {
    id: 'messenger',
    name: 'Мессенджер / Чат-приложение',
    keywords: ['мессендж', 'messenger', 'чат', 'chat', 'сообщен', 'message', 'диалог'],
    marketSize: '$100 млрд+ глобально',
    trends: ['Шифрование', 'Боты и AI', 'Интеграции', 'Бизнес-функции'],
    barriers: ['Сетевой эффект', 'Привычки пользователей', 'Регулирование'],
    positioning: 'безопасный мессенджер для бизнеса и частного общения'
  },
  {
    id: 'task',
    name: 'Управление задачами / Проектами',
    keywords: ['задач', 'task', 'проект', 'project', 'kanban', 'trello', 'agile', 'scrumban'],
    marketSize: '$5 млрд глобально',
    trends: ['AI-планирование', 'Асинхронная работа', 'Интеграции', 'Геймификация'],
    barriers: ['Привычки команды', 'Сложность перехода', 'Обучение'],
    positioning: 'простой инструмент для командной работы'
  },
  {
    id: 'hr',
    name: 'HR-платформа / Управление персоналом',
    keywords: ['hr', 'кадр', 'персонал', 'сотрудник', 'employee', 'рекрут', 'найм', 'onboard'],
    marketSize: '$30 млрд глобально',
    trends: ['Remote work инструменты', 'AI-рекрутинг', 'Wellness программы', 'Аналитика персонала'],
    barriers: ['Защита персональных данных', 'Интеграция с существующими системами', 'Принятие HR'],
    positioning: 'современная платформа управления талантами'
  },
  {
    id: 'fintech',
    name: 'FinTech / Финансовое приложение',
    keywords: ['фин', 'fin', 'банк', 'bank', 'платёж', 'payment', 'деньги', 'money', 'бухгалт', 'account'],
    marketSize: '$300 млрд глобально',
    trends: ['Neobanking', 'Криптовалюты', 'BNPL', 'Открытые API'],
    barriers: ['Регулирование', 'Безопасность', 'Доверие пользователей'],
    positioning: 'финансовый инструмент для цифрового поколения'
  },
  {
    id: 'education',
    name: 'EdTech / Образовательная платформа',
    keywords: ['образован', 'education', 'курс', 'course', 'обучен', 'learning', 'студент', 'student'],
    marketSize: '$400 млрд глобально',
    trends: ['Microlearning', 'AI-персонализация', 'VR/AR', 'Геймификация'],
    barriers: ['Качество контента', 'Мотивация студентов', 'Аккредитация'],
    positioning: 'интерактивная платформа онлайн-обучения'
  },
  {
    id: 'health',
    name: 'HealthTech / Медицинское приложение',
    keywords: ['медицин', 'health', 'врач', 'doctor', 'здоров', 'health', 'клиник', 'clinic', 'пациент'],
    marketSize: '$500 млрд глобально',
    trends: ['Telemedicine', 'AI-диагностика', 'Wearables', 'Персонализированная медицина'],
    barriers: ['Регулирование', 'Защита данных', 'Принятие врачами'],
    positioning: 'цифровой помощник для здоровья'
  },
  {
    id: 'logistics',
    name: 'Логистика / Доставка',
    keywords: ['логистик', 'logistics', 'доставк', 'delivery', 'склад', 'warehouse', 'транспор', 'transport'],
    marketSize: '$200 млрд глобально',
    trends: ['Автономная доставка', 'Real-time трекинг', 'Оптимизация маршрутов AI', 'Устойчивость'],
    barriers: ['Инфраструктура', 'Регулирование', 'Стоимость'],
    positioning: 'умная платформа логистики'
  },
  {
    id: 'booking',
    name: 'Онлайн-запись / Бронирование',
    keywords: ['запись', 'брон', 'календар', 'слот', 'приём', 'расписание', 'записаться', 'онлайн-запись', 'yclients', 'dikidi', 'салон', 'мастер', 'клиник', 'красот', 'услуг'],
    marketSize: '$2 млрд глобально (online booking)',
    trends: ['Интеграция с мессенджерами', 'Автоматические напоминания', 'AI-подбор времени', 'Виджеты для сайтов'],
    barriers: ['Привычка записываться по телефону', 'Интеграция с календарями', 'Стоимость SMS'],
    positioning: 'простой сервис онлайн-записи для бизнеса'
  }
];

// База конкурентов по типам продуктов
const COMPETITORS_DB: Record<string, { direct: Competitor[]; indirect: IndirectCompetitor[] }> = {
  booking: {
    direct: [
      {
        name: 'YCLIENTS',
        url: 'https://yclients.ru',
        country: 'Россия',
        description: 'Лидер рынка онлайн-записи для салонов красоты и медицины',
        features: 'Онлайн-запись, CRM, склад, бухгалтерия, виджеты, мессенджеры',
        pricing: 'от 990₽/мес',
        targetAudience: 'Салоны красоты, клиники, образовательные центры',
        strengths: ['Полный функционал', 'Интеграции', 'Бесплатный тариф', 'Мобильное приложение'],
        weaknesses: ['Сложность интерфейса', 'Цена расширенных функций', 'Перегруженность'],
        opportunities: ['AI-ассистент', 'Интеграция с маркетплейсами', 'Видео-консультации'],
        threats: ['Dikidi', 'Нишевые решения', 'Собственные разработки'],
        functionalityScore: '⭐⭐⭐⭐⭐',
        priceScore: '⭐⭐⭐',
        uxScore: '⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      },
      {
        name: 'Dikidi',
        url: 'https://dikidi.net',
        country: 'Россия',
        description: 'Простой сервис онлайн-записи с современным интерфейсом',
        features: 'Онлайн-запись, расписание, уведомления, CRM, виджеты',
        pricing: 'от 490₽/мес',
        targetAudience: 'Мастера, маленькие салоны',
        strengths: ['Простота', 'Дизайн', 'Цена', 'Быстрый старт'],
        weaknesses: ['Ограниченный функционал', 'Меньше интеграций', 'Нет склада'],
        opportunities: ['Расширение функций', 'Бизнес-аналитика', 'Галерея работ'],
        threats: ['YCLIENTS', 'Бесплатные альтернативы'],
        functionalityScore: '⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐⭐',
        uxScore: '⭐⭐⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      },
      {
        name: 'Sonline',
        url: 'https://sonline.su',
        country: 'Россия',
        description: 'Сервис онлайн-записи для салонов и клиник',
        features: 'Онлайн-запись, расписание, SMS-уведомления, отчёты',
        pricing: 'от 290₽/мес',
        targetAudience: 'Салоны красоты, медицинские центры',
        strengths: ['Низкая цена', 'Простота', 'SMS включены'],
        weaknesses: ['Базовый функционал', 'Мало интеграций'],
        opportunities: ['Интеграции', 'AI-функции', 'Расширение'],
        threats: ['Крупные конкуренты', 'Ценовая война'],
        functionalityScore: '⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐⭐',
        uxScore: '⭐⭐⭐',
        supportScore: '⭐⭐⭐'
      }
    ],
    indirect: [
      {
        name: 'WhatsApp / Telegram',
        description: 'Мессенджеры для записи через личные сообщения',
        approach: 'Переписка с мастером/салоном',
        overlap: 'Коммуникация для записи',
        differentiation: 'Нет автоматизации, календаря, напоминаний'
      },
      {
        name: 'Google Calendar',
        description: 'Календарь для ручного управления записями',
        approach: 'Ручное ведение расписания',
        overlap: 'Управление временем',
        differentiation: 'Нет клиентской части, онлайн-записи'
      },
      {
        name: 'Телефонная запись',
        description: 'Традиционный способ записи по телефону',
        approach: 'Звонок в салон/клинику',
        overlap: 'Запись на услугу',
        differentiation: 'Требует времени, нет напоминаний'
      }
    ]
  },
  ats: {
    direct: [
      {
        name: 'Манго Офис',
        url: 'https://mango-office.ru',
        country: 'Россия',
        description: 'Облачная АТС с интеграцией CRM и аналитикой звонков',
        features: 'Виртуальная АТС, интеграция CRM, запись звонков, IVR, аналитика',
        pricing: 'от 650₽/мес за пользователя',
        targetAudience: 'Малый и средний бизнес в РФ',
        strengths: ['Локализация для РФ', 'Интеграция с российскими CRM', 'Техподдержка на русском', 'Работа с российскими операторами'],
        weaknesses: ['Ограниченный функционал аналитики', 'Устаревший интерфейс', 'Сложность настройки интеграций'],
        opportunities: ['Расширение AI-функций', 'Мобильное приложение', 'Интеграция с мессенджерами'],
        threats: ['Выход на рынок зарубежных игроков', 'Снижение цен конкурентами', 'Изменения в законодательстве'],
        functionalityScore: '⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐',
        uxScore: '⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      },
      {
        name: 'Telphin',
        url: 'https://telphin.ru',
        country: 'Россия',
        description: 'IP-телефония и виртуальная АТС для бизнеса',
        features: 'Виртуальная АТС, SIP-телефония, интеграция с 1С, запись разговоров',
        pricing: 'от 290₽/мес',
        targetAudience: 'Малый бизнес, колл-центры',
        strengths: ['Низкая цена', 'Простота настройки', 'Интеграция с 1С'],
        weaknesses: ['Базовый функционал', 'Ограниченная аналитика', 'Старый UI'],
        opportunities: ['Обновление интерфейса', 'AI-функции', 'Мобильное приложение'],
        threats: ['Более технологичные конкуренты', 'Ценовая война'],
        functionalityScore: '⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐⭐',
        uxScore: '⭐⭐',
        supportScore: '⭐⭐⭐'
      },
      {
        name: 'UIS (Юждес)',
        url: 'https://uiscom.ru',
        country: 'Россия',
        description: 'Облачная контакт-центр и виртуальная АТС',
        features: 'Виртуальная АТС, контакт-центр, интеграция CRM, аналитика',
        pricing: 'от 600₽/мес',
        targetAudience: 'Средний и крупный бизнес',
        strengths: ['Мощный контакт-центр', 'Глубокая аналитика', 'Интеграции'],
        weaknesses: ['Сложность для новичков', 'Высокая цена расширенных функций', 'Долгое внедрение'],
        opportunities: ['SMB-сегмент', 'AI-ассистенты', 'Самостоятельная настройка'],
        threats: ['Упрощение решений конкурентами', 'Экономический фактор'],
        functionalityScore: '⭐⭐⭐⭐⭐',
        priceScore: '⭐⭐⭐',
        uxScore: '⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      }
    ],
    indirect: [
      {
        name: 'Telegram',
        description: 'Мессенджер с функциями звонков и групповых чатов',
        approach: 'Бесплатная связь через интернет',
        overlap: 'Групповые звонки, контакты',
        differentiation: 'Не бизнес-ориентирован, нет CRM-интеграций'
      },
      {
        name: 'WhatsApp Business',
        description: 'Бизнес-версия мессенджера для общения с клиентами',
        approach: 'Чат-коммуникация с клиентами',
        overlap: 'Клиентское общение',
        differentiation: 'Только чат, нет телефонии'
      },
      {
        name: 'Skype',
        description: 'Платформа для видеозвонков и чатов',
        approach: 'Видеоконференции и звонки',
        overlap: 'Звонки, конференц-связь',
        differentiation: 'Устаревший продукт, нет бизнес-функций АТС'
      }
    ]
  },
  dashboard: {
    direct: [
      {
        name: 'Yandex DataLens',
        url: 'https://cloud.yandex.ru/services/datalens',
        country: 'Россия',
        description: 'Бесплатный BI-сервис для визуализации данных',
        features: 'Дашборды, визуализации, интеграция с Yandex Cloud, collaborative редактирование',
        pricing: 'Бесплатно',
        targetAudience: 'Компании любого размера',
        strengths: ['Бесплатность', 'Интеграция с Yandex', 'Простота', 'Русский язык'],
        weaknesses: ['Ограниченная кастомизация', 'Зависимость от Yandex', 'Ограниченные источники данных'],
        opportunities: ['Расширение источников', 'AI-инсайты', 'Мобильное приложение'],
        threats: ['Изменение тарифной политики', 'Выход международных игроков'],
        functionalityScore: '⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐⭐',
        uxScore: '⭐⭐⭐⭐',
        supportScore: '⭐⭐⭐'
      },
      {
        name: 'Grafana',
        url: 'https://grafana.com',
        country: 'США',
        description: 'Open-source платформа для визуализации и мониторинга',
        features: 'Гибкие дашборды, алертинг, множество плагинов, open source',
        pricing: 'Open source / Enterprise от $50/мес',
        targetAudience: 'IT-команды, DevOps',
        strengths: ['Гибкость', 'Open source', 'Community', 'Plugin ecosystem'],
        weaknesses: ['Сложность настройки', 'Требует технических знаний', 'Нет русского языка'],
        opportunities: ['Упрощение для бизнеса', 'SaaS-версия', 'No-code редактор'],
        threats: ['Cloud-native решения', 'Встроенные дашборды в других продуктах'],
        functionalityScore: '⭐⭐⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐⭐',
        uxScore: '⭐⭐⭐',
        supportScore: '⭐⭐⭐'
      },
      {
        name: 'Tableau',
        url: 'https://tableau.com',
        country: 'США',
        description: 'Лидер рынка BI с мощной визуализацией',
        features: 'Расширенная визуализация, AI-инсайты, data prep, collaboration',
        pricing: 'от $15/мес за пользователя',
        targetAudience: 'Средний и крупный бизнес',
        strengths: ['Мощный функционал', 'Лидер рынка', 'AI-возможности', 'Интеграции'],
        weaknesses: ['Высокая цена', 'Сложность обучения', 'Нет локализации'],
        opportunities: ['SMB-сегмент', 'Локализация', 'Упрощение'],
        threats: ['Бесплатные альтернативы', 'Российские решения'],
        functionalityScore: '⭐⭐⭐⭐⭐',
        priceScore: '⭐⭐',
        uxScore: '⭐⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      }
    ],
    indirect: [
      {
        name: 'Google Sheets',
        description: 'Табличный процессор с визуализацией',
        approach: 'Самостоятельное создание отчётов',
        overlap: 'Визуализация данных, совместная работа',
        differentiation: 'Нет real-time дашбордов, ограниченная визуализация'
      },
      {
        name: 'Excel / Power BI',
        description: 'Майкрософт экосистема для работы с данными',
        approach: 'Интеграция с Office 365',
        overlap: 'Отчёты, визуализация',
        differentiation: 'Сложность, цена, привязка к Microsoft'
      },
      {
        name: 'Notion',
        description: 'All-in-one workspace с базами данных',
        approach: 'Самостоятельное ведение базы',
        overlap: 'Структурирование данных',
        differentiation: 'Нет продвинутой аналитики, дашборды ограничены'
      }
    ]
  },
  crm: {
    direct: [
      {
        name: 'Битрикс24',
        url: 'https://bitrix24.ru',
        country: 'Россия',
        description: 'Комплексная CRM с функциями управления проектами',
        features: 'CRM, задачи, коммуникации, сайт, интернет-магазин',
        pricing: 'Бесплатно до 5 пользователей / от 2490₽/мес',
        targetAudience: 'Малый и средний бизнес',
        strengths: ['Бесплатный тариф', 'Всё в одном', 'Локализация', 'Интеграции'],
        weaknesses: ['Перегруженность', 'Сложность', 'Скорость работы'],
        opportunities: ['Упрощение интерфейса', 'AI-функции', 'Мобильность'],
        threats: ['Конкуренция с нишевыми решениями', 'Отток пользователей'],
        functionalityScore: '⭐⭐⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐⭐',
        uxScore: '⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      },
      {
        name: 'AmoCRM',
        url: 'https://amocrm.ru',
        country: 'Россия',
        description: 'Простая CRM для управления продажами',
        features: 'Воронка продаж, интеграции, автоматизация, аналитика',
        pricing: 'от 799₽/мес',
        targetAudience: 'Малый бизнес, отделы продаж',
        strengths: ['Простота', 'Воронка продаж', 'Интуитивность', 'Интеграции'],
        weaknesses: ['Ограниченный функционал', 'Нет задач/проектов', 'Цена растёт с пользователями'],
        opportunities: ['Расширение функционала', 'AI-рекомендации', 'Мобильность'],
        threats: ['Битрикс24', 'Зарубежные решения', 'Ценовая конкуренция'],
        functionalityScore: '⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐',
        uxScore: '⭐⭐⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      },
      {
        name: 'Salesforce',
        url: 'https://salesforce.com',
        country: 'США',
        description: 'Мировой лидер CRM для крупного бизнеса',
        features: 'Sales Cloud, Service Cloud, Marketing Cloud, AI Einstein',
        pricing: 'от $25/мес за пользователя',
        targetAudience: 'Средний и крупный бизнес',
        strengths: ['Мощный функционал', 'Экосистема', 'AI', 'Интеграции'],
        weaknesses: ['Высокая цена', 'Сложность', 'Нет русского языка', 'Санкции'],
        opportunities: ['Российский рынок', 'SMB сегмент', 'Упрощение'],
        threats: ['Российские решения', 'Санкции', 'Цена'],
        functionalityScore: '⭐⭐⭐⭐⭐',
        priceScore: '⭐⭐',
        uxScore: '⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      }
    ],
    indirect: [
      {
        name: 'Google Contacts',
        description: 'Адресная книга Google',
        approach: 'Хранение контактов',
        overlap: 'Хранение контактов',
        differentiation: 'Нет функций продаж, нет воронки'
      },
      {
        name: 'Trello',
        description: 'Kanban-доска для управления задачами',
        approach: 'Визуальное управление',
        overlap: 'Управление процессами',
        differentiation: 'Нет CRM-функций, нет продаж'
      },
      {
        name: 'Excel / Google Sheets',
        description: 'Табличные процессоры',
        approach: 'Самостоятельное ведение базы клиентов',
        overlap: 'Хранение данных о клиентах',
        differentiation: 'Нет автоматизации, нет воронки продаж'
      }
    ]
  }
};

// Функция определения типа продукта
function detectProductType(text: string): ProductType {
  const lowerText = text.toLowerCase();
  
  // Ищем наиболее подходящий тип продукта
  let bestMatch: ProductType | null = null;
  let bestScore = 0;
  
  for (const type of PRODUCT_TYPES) {
    let score = 0;
    for (const keyword of type.keywords) {
      if (lowerText.includes(keyword.toLowerCase())) {
        score += keyword.length; // Более длинные ключевые слова более специфичны
      }
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = type;
    }
  }
  
  // Если ничего не найдено, возвращаем тип по умолчанию
  if (!bestMatch) {
    return {
      id: 'default',
      name: 'Программный продукт / SaaS',
      keywords: [],
      marketSize: 'Зависит от конкретной ниши',
      trends: ['AI-интеграция', 'Облачные решения', 'Мобильность', 'Персонализация'],
      barriers: ['Конкуренция', 'Привлечение пользователей', 'Монетизация'],
      positioning: 'современное решение для цифровых потребностей'
    };
  }
  
  return bestMatch;
}

// Функция генерации конкурентов
function generateCompetitors(productType: ProductType, idea: { name: string; description: string; functions: string[] }): { direct: Competitor[]; indirect: IndirectCompetitor[] } {
  // Проверяем есть ли готовая база для этого типа
  if (COMPETITORS_DB[productType.id]) {
    return COMPETITORS_DB[productType.id];
  }
  
  // Если нет готовой базы, генерируем общих конкурентов
  return {
    direct: [
      {
        name: 'Лидер рынка',
        url: 'https://example.com',
        country: 'США/Европа',
        description: 'Ведущий игрок в нише с широким функционалом',
        features: 'Полный набор функций, интеграции, API',
        pricing: 'От $50-200/мес',
        targetAudience: 'Средний и крупный бизнес',
        strengths: ['Бренд', 'Функциональность', 'Надёжность', 'Поддержка'],
        weaknesses: ['Цена', 'Сложность', 'Нет локализации', 'Долгое внедрение'],
        opportunities: ['Выход на новые рынки', 'SMB-сегмент', 'AI-функции'],
        threats: ['Новые игроки', 'Open source альтернативы', 'Экономический фактор'],
        functionalityScore: '⭐⭐⭐⭐⭐',
        priceScore: '⭐⭐',
        uxScore: '⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      },
      {
        name: 'Российский аналог',
        url: 'https://example.ru',
        country: 'Россия',
        description: 'Локальное решение с адаптацией под рынок РФ',
        features: 'Базовый функционал, интеграция с российскими сервисами',
        pricing: 'От 1000-5000₽/мес',
        targetAudience: 'Российский бизнес',
        strengths: ['Локализация', 'Поддержка на русском', 'Интеграции', 'Цена'],
        weaknesses: ['Ограниченный функционал', 'Масштабируемость', 'Технологии'],
        opportunities: ['Развитие функций', 'AI', 'Мобильность'],
        threats: ['Зарубежные решения', 'Кадры', 'Технологии'],
        functionalityScore: '⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐',
        uxScore: '⭐⭐⭐',
        supportScore: '⭐⭐⭐⭐'
      },
      {
        name: 'Start-up конкурент',
        url: 'https://startup.example.com',
        country: 'Интернациональный',
        description: 'Молодой проект с инновационным подходом',
        features: 'Современный UI, AI-функции, быстрый старт',
        pricing: 'Freemium / от $10-30/мес',
        targetAudience: 'Стартапы, малый бизнес',
        strengths: ['Инновации', 'Современный UI', 'Гибкость', 'Цена'],
        weaknesses: ['Надёжность', 'Ограниченный функционал', 'Поддержка', 'Документация'],
        opportunities: ['Развитие', 'Инвестиции', 'Партнёрства'],
        threats: ['Большие игроки', 'Финансирование', 'Команда'],
        functionalityScore: '⭐⭐⭐',
        priceScore: '⭐⭐⭐⭐⭐',
        uxScore: '⭐⭐⭐⭐⭐',
        supportScore: '⭐⭐'
      }
    ],
    indirect: [
      {
        name: 'Excel / Google Sheets',
        description: 'Табличные процессоры для самостоятельного учёта',
        approach: 'Самостоятельное создание системы',
        overlap: 'Хранение и обработка данных',
        differentiation: 'Нет автоматизации, требует ручной работы'
      },
      {
        name: 'Notion',
        description: 'All-in-one workspace',
        approach: 'Гибкое структурирование информации',
        overlap: 'Управление данными и процессами',
        differentiation: 'Нет специализации под конкретную задачу'
      },
      {
        name: 'Ручное управление / Legacy-системы',
        description: 'Старые методы и системы',
        approach: 'Традиционные процессы',
        overlap: 'Решение проблемы',
        differentiation: 'Низкая эффективность, несовременность'
      }
    ]
  };
}


// === ФУНКЦИЯ АНАЛИЗА ИДЕИ ИЗ ИСХОДНОГО ТЕКСТА ===
// ИЗВЛЕКАЕТ реальные данные из текста транскрипции, НЕ использует шаблоны
interface AnalysisResult {
  name: string;
  description: string;
  context: string;
  valueProposition: string;
  functions: string[];
  uniqueAdvantage: string;
  userTypes: { type: string; description: string; motivation: string; pains: string }[];
  roles: { role: string; rights: string; duties: string; restrictions: string }[];
  useCases: { title: string; actor: string; precondition: string; steps: string[]; result: string }[];
  criticalRisks: { title: string; description: string; impact: string; mitigation: string }[];
  significantRisks: { title: string; description: string; impact: string; mitigation: string }[];
  moderateRisks: string[];
  techDifficulties: string[];
  marketBarriers: string[];
  resourceConstraints: string[];
  valueImprovements: string[];
  mvpSimplifications: string[];
  differentiation: string[];
  hypotheses: string[];
  scores: {
    relevance: number; relevanceComment: string;
    feasibility: number; feasibilityComment: string;
    marketPotential: number; marketPotentialComment: string;
    competitiveness: number; competitivenessComment: string;
    riskLevel: number; riskLevelComment: string;
  };
  overallConclusion: string;
}

function analyzeSourceIdea(sourceText: string): AnalysisResult {
  const lowerText = sourceText.toLowerCase();
  
  // === ИЗВЛЕКАЕМ РЕАЛЬНЫЕ ДАННЫЕ ИЗ ТЕКСТА ===
  
  // 1. ИЗВЛЕКАЕМ НАЗВАНИЕ
  let name = '';
  const namePatterns = [
    /(?:названи[еи]|продукт|проект|сервис|приложение|платформа|идея|хотим сделать|делаем|созда[её]м)[^:]*[:«"]?\s*([А-Яа-яA-Za-z0-9\s]{2,50})["»]?/i,
    /(?:это|называется)\s+["«]?([А-Яа-яA-Za-z0-9\s]{3,40})["»]?/i,
  ];
  
  for (const pattern of namePatterns) {
    const match = sourceText.match(pattern);
    if (match && match[1]) {
      const extracted = match[1].trim().replace(/^["«»]+|["«»]+$/g, '');
      if (extracted.length > 2 && extracted.length < 50 && !extracted.match(/^(это|который|которая|чтобы|потом|потому)$/i)) {
        name = extracted;
        break;
      }
    }
  }
  
  // Fallback - первые значащие слова
  if (!name) {
    const words = sourceText.split(/[\s\n]+/).filter(w => w.length > 3 && !['это', 'который', 'которая', 'чтобы', 'потому', 'тогда', 'поэтому', 'сейчас', 'потом'].includes(w.toLowerCase()));
    if (words.length >= 2) {
      name = words.slice(0, 3).join(' ');
    }
  }
  
  if (!name) name = 'Продукт';
  
  // 2. ИЗВЛЕКАЕМ ОПИСАНИЕ из текста
  let description = '';
  const sentences = sourceText.split(/[.!?]+/).filter(s => s.trim().length > 15);
  if (sentences.length > 0) {
    description = sentences.slice(0, 3).join('. ').trim();
    if (description.length > 300) {
      description = description.substring(0, 300) + '...';
    }
  }
  if (!description) description = 'Описание из предоставленного текста';
  
  // 3. ИЗВЛЕКАЕМ КОНТЕКСТ - проблемы, предпосылки
  const contextMatches: string[] = [];
  const contextPatterns = [
    /(?:проблема|сложност[ьи]|трудност[ьи]|неудобств[оа]|боли)[^.]*[.!?]/gi,
    /(?:сейчас|в настоящее время|ситуация|на рынке)[^.]*[.!?]/gi,
    /(?:потому что|так как|из-за|причина|поэтому)[^.]*[.!?]/gi,
  ];
  for (const p of contextPatterns) {
    const m = sourceText.match(p);
    if (m) contextMatches.push(...m.slice(0, 2));
  }
  const context = contextMatches.length > 0 
    ? contextMatches.join(' ').substring(0, 400)
    : sourceText.substring(Math.floor(sourceText.length * 0.1), Math.floor(sourceText.length * 0.4)).trim().substring(0, 400);
  
  // 4. ИЗВЛЕКАЕМ ЦЕННОСТЬ
  let valueProposition = '';
  const valuePatterns = [
    /(?:ценность|ценност[а-я]*|преимуществ[оаы]|выгод[аы]|польз[аы]|value)[^:]*[:.]?\s*([А-Яа-яA-Za-z0-9\s.,()-]{10,200})/i,
    /(?:экономит|сокращает|упрощает|автоматизирует|улучшает|помогает)[^.]*[.]/i,
    /(?:чтобы|для того чтобы)\s+([А-Яа-яA-Za-z0-9\s.,()-]{10,150})/i,
  ];
  for (const p of valuePatterns) {
    const m = sourceText.match(p);
    if (m && (m[1] || m[0])) {
      valueProposition = (m[1] || m[0]).trim();
      break;
    }
  }
  if (!valueProposition) valueProposition = description.substring(0, 100);
  
  // 5. ИЗВЛЕКАЕМ ФУНКЦИИ
  const functions: string[] = [];
  const funcPatterns = [
    /(?:функци[ия]|возможност[ьи]|особенност[ьи]|может|умеет|делает|позволяет|реализует|нужно сделать|надо добавить|хотим реализовать)[^:]*[:.]?\s*([А-Яа-яA-Za-z0-9\s.,()-]{10,100})/gi,
    /\d+[.)]\s*([А-Яа-яA-Za-z0-9\s.,()-]{5,80})/g,
  ];
  for (const p of funcPatterns) {
    const matches = [...sourceText.matchAll(p)];
    for (const m of matches) {
      if (m[1]) {
        const func = m[1].trim();
        if (func.length > 5 && func.length < 100 && !functions.includes(func)) {
          functions.push(func);
        }
      }
      if (functions.length >= 6) break;
    }
    if (functions.length >= 6) break;
  }
  // Ищем глаголы действия если мало
  if (functions.length < 3) {
    const actionVerbs = sourceText.match(/(?:записывать|бронировать|отправлять|получать|создавать|управлять|просматривать|анализировать|интегрировать|автоматизировать|отслеживать|планировать|оплачивать|настраивать)[^.,]*[.,]/gi);
    if (actionVerbs) functions.push(...actionVerbs.slice(0, 5 - functions.length).map(v => v.trim()));
  }
  if (functions.length === 0) {
    functions.push('Основная функция продукта', 'Дополнительные возможности', 'Настройки');
  }
  
  // 6. ИЗВЛЕКАЕМ УНИКАЛЬНОЕ ПРЕИМУЩЕСТВО
  let uniqueAdvantage = '';
  const advPatterns = [
    /(?:уникальн[оеы]|отлич[иае][тся]?|особ[еы]нност[ьи]|в отличие от|главное|главн[ыый] преимущество)[^.]*[.]/gi,
    /(?:не как|по-другому|иначе|нов[ыый] подход)[^.]*[.]/gi,
  ];
  for (const p of advPatterns) {
    const m = sourceText.match(p);
    if (m && m.length > 0) {
      uniqueAdvantage = m[0].trim();
      break;
    }
  }
  if (!uniqueAdvantage) uniqueAdvantage = 'Требует определения после custdev';
  
  // 7. ИЗВЛЕКАЕМ ТИПЫ ПОЛЬЗОВАТЕЛЕЙ
  const userTypes: { type: string; description: string; motivation: string; pains: string }[] = [];
  const userMatches = sourceText.match(/(?:пользовател[ьи]|клиент[ыа]?|заказчик[и]?|менеджер[ыа]?|администратор[ыа]?|врач[иа]?|специалист[ыа]?|мастер[аы]?|пациент[ыа]?|работник[и]?|сотрудник[и]?|руководител[ьи]?|директор[аы]?)[^.,]*[.,]/gi);
  if (userMatches && userMatches.length > 0) {
    const uniqueUsers = [...new Set(userMatches.map(u => u.split(/[\s,]/)[0]))];
    uniqueUsers.slice(0, 4).forEach(userType => {
      userTypes.push({
        type: userType.trim(),
        description: 'Упомянут в тексте',
        motivation: 'Извлечь из контекста',
        pains: 'Определить из проблем в тексте'
      });
    });
  }
  if (userTypes.length === 0) {
    userTypes.push({ type: 'Пользователь', description: 'Конечный пользователь', motivation: 'Решение задач', pains: 'Боли из текста' });
  }
  
  // 8. РОЛИ
  const roles = userTypes.map(ut => ({
    role: ut.type,
    rights: 'Определяется функционалом',
    duties: 'Использование по назначению',
    restrictions: 'Ограничения доступа'
  }));
  
  // 9. USE CASES из текста
  const useCases: { title: string; actor: string; precondition: string; steps: string[]; result: string }[] = [];
  const scenarioMatches = sourceText.match(/(?:сценари[йия]|процесс|алгоритм|шаг[иа]?|этап[ыа]?|последовательность|пользователь делает|пользователь открывает|клиент заходит|клиент выбирает)[^:]*[:.]?\s*([А-Яа-яA-Za-z0-9\s.,()-]{20,300})/gi);
  if (scenarioMatches && scenarioMatches.length > 0) {
    scenarioMatches.slice(0, 3).forEach((match, i) => {
      useCases.push({
        title: `Сценарий ${i + 1}`,
        actor: 'Пользователь',
        precondition: 'Исходя из контекста',
        steps: match.split(/[.,]/).filter(s => s.trim().length > 3).slice(0, 5),
        result: 'Выполнено'
      });
    });
  }
  if (useCases.length === 0) {
    useCases.push({ title: 'Основной сценарий', actor: 'Пользователь', precondition: 'Доступ к системе', steps: ['Открыть', 'Выполнить', 'Получить результат'], result: 'Задача выполнена' });
  }
  
  // 10. РИСКИ из текста
  const criticalRisks: { title: string; description: string; impact: string; mitigation: string }[] = [];
  const significantRisks: { title: string; description: string; impact: string; mitigation: string }[] = [];
  const moderateRisks: string[] = [];
  
  const riskMatches = sourceText.match(/(?:риск|опасност[ьи]|угроз[аы]|проблем[аы]|сложност[ьи]|трудност[ьи]|барьер|конкурент|слабост[ьи]|недостаток)[^.]*[.]/gi);
  if (riskMatches) {
    riskMatches.slice(0, 3).forEach(m => moderateRisks.push(m.trim()));
  }
  
  // 11. ТЕХНИЧЕСКИЕ СЛОЖНОСТИ
  const techDifficulties: string[] = [];
  const techMatches = sourceText.match(/(?:интеграци[ия]|api|база данных|архитектур[аы]|безопасност[ьи]|масштабировани[ея]|производительност[ьи]|технически[ей]|сложност[ьи] с|проблем[аы] с)[^.]*[.]/gi);
  if (techMatches) techDifficulties.push(...techMatches.slice(0, 4).map(m => m.trim()));
  if (techDifficulties.length === 0) techDifficulties.push('Требует технической оценки');
  
  // 12. РЫНОЧНЫЕ БАРЬЕРЫ
  const marketBarriers: string[] = [];
  const barrierMatches = sourceText.match(/(?:конкурент[ыа]?|рынок|барьер|вход[аы]?|стоимость|цена|бюджет|деньги|финансировани[ея])[^.]*[.]/gi);
  if (barrierMatches) marketBarriers.push(...barrierMatches.slice(0, 4).map(m => m.trim()));
  if (marketBarriers.length === 0) marketBarriers.push('Требует рыночного анализа');
  
  // 13. РЕСУРСНЫЕ ОГРАНИЧЕНИЯ
  const resourceConstraints: string[] = [];
  if (lowerText.includes('бюджет') || lowerText.includes('ресурс') || lowerText.includes('время') || lowerText.includes('команда')) {
    resourceConstraints.push('Упомянутые в тексте ограничения');
  } else {
    resourceConstraints.push('Требует оценки ресурсов');
  }
  
  // 14. КОНКРЕТНЫЕ УЛУЧШЕНИЯ ЦЕННОСТИ на основе анализа текста
  const valueImprovements: string[] = [];
  
  // Ищем проблемы в тексте и предлагаем решения
  const problemMatches = sourceText.match(/(?:проблема|неудобство|сложность|трудность|не хватает|не работает|плохо)[^.]*[.]/gi);
  if (problemMatches && problemMatches.length > 0) {
    problemMatches.slice(0, 2).forEach(p => {
      valueImprovements.push(`Решить: ${p.trim().substring(0, 60)}... — это повысит удовлетворённость пользователей`);
    });
  }
  
  // Предлагаем на основе функций
  if (functions.length > 0) {
    valueImprovements.push(`Усилить "${functions[0].substring(0, 40)}..." — ключевая функция требует максимального удобства`);
  }
  
  if (valueImprovements.length === 0) {
    valueImprovements.push(`Добавить onboarding для новых пользователей — снизит порог входа`);
  }
  
  // 15. УПРОЩЕНИЕ MVP
  const mvpSimplifications: string[] = [];
  
  // Определяем что можно отложить
  if (functions.length > 3) {
    mvpSimplifications.push(`Отложить: "${functions[functions.length - 1]?.substring(0, 30) || 'расширенные функции'}..." — не критично для первого релиза`);
  }
  mvpSimplifications.push(`MVP: ${functions.slice(0, 2).join(' + ') || 'основной функционал'} — минимальный набор для проверки гипотезы`);
  mvpSimplifications.push(`Отложить интеграции — сфокусироваться на core-value`);
  
  // 16. ДИФФЕРЕНЦИАЦИЯ - ищем упоминания конкурентов и аналогов
  const differentiation: string[] = [];
  
  const competitorMentions = sourceText.match(/(?:конкурент|аналог|похож[ие]|похожий на|альтернатива|вместо|лучше чем)[^.]*[.]/gi);
  if (competitorMentions && competitorMentions.length > 0) {
    competitorMentions.slice(0, 2).forEach(c => {
      differentiation.push(`Отличие: ${c.trim().substring(0, 50)}...`);
    });
  }
  
  if (uniqueAdvantage && uniqueAdvantage !== 'Требует определения после custdev') {
    differentiation.push(`Уникальность: ${uniqueAdvantage.substring(0, 60)}`);
  }
  
  if (differentiation.length === 0) {
    differentiation.push(`Фокус на конкретной нише — не пытаться охватить весь рынок`);
    differentiation.push(`Простота и скорость — ключевое преимущество перед перегруженными аналогами`);
  }
  
  // 17. ГИПОТЕЗЫ ДЛЯ ВАЛИДАЦИИ
  const hypotheses: string[] = [];
  
  // Формулируем гипотезы на основе контекста
  if (userTypes.length > 0) {
    hypotheses.push(`Гипотеза: ${userTypes[0].type} готов платить за решение → Проверить: pre-sales/воронка продаж`);
  }
  if (functions.length > 0) {
    hypotheses.push(`Гипотеза: "${functions[0].substring(0, 30)}..." — killer-feature → Проверить: A/B тест mockup'ов`);
  }
  hypotheses.push(`Гипотеза: Retention > 30% на week-1 → Проверить: tracking в MVP`);
  
  if (hypotheses.length < 3) {
    hypotheses.push(`Гипотеза: Users вернутся без пушей → Проверить: отключить пуш-уведомления в тестовой группе`);
  }
  
  // 18. ОЦЕНКИ
  const scores = {
    relevance: 7,
    relevanceComment: 'Требует валидации на основе извлечённых из текста данных',
    feasibility: 7,
    feasibilityComment: 'Техническая реализуемость требует уточнения',
    marketPotential: 7,
    marketPotentialComment: 'Рыночный потенциал зависит от позиционирования',
    competitiveness: 6,
    competitivenessComment: 'Конкурентная среда требует анализа',
    riskLevel: 6,
    riskLevelComment: 'Риски извлечены из контекста, требуют митигации'
  };
  
  const overallConclusion = `Проанализирован предоставленный текст и извлечены ключевые данные о продукте "${name}". Рекомендуется провести custdev для валидации гипотез и уточнения деталей, не указанных в исходном тексте.`;
  
  return {
    name,
    description,
    context,
    valueProposition,
    functions,
    uniqueAdvantage,
    userTypes,
    roles,
    useCases,
    criticalRisks: criticalRisks.length > 0 ? criticalRisks : [{ title: 'Рыночный риск', description: 'Требует валидации идеи', impact: 'Высокое', mitigation: 'Провести custdev' }],
    significantRisks: significantRisks.length > 0 ? significantRisks : [{ title: 'Технический риск', description: 'Сложность реализации', impact: 'Среднее', mitigation: 'MVP для проверки' }],
    moderateRisks: moderateRisks.length > 0 ? moderateRisks : ['Требует дополнительного анализа'],
    techDifficulties,
    marketBarriers,
    resourceConstraints,
    valueImprovements,
    mvpSimplifications,
    differentiation,
    hypotheses,
    scores,
    overallConclusion
  };
}


function getFallbackResponse(agentType: string, message: string): string {
  const idea = extractFormedIdea(message);
  const lowerMessage = message.toLowerCase();
  
  // === АНАЛИТИК ИДЕЙ ===
  if (agentType === 'transcription_analyst') {
    // Извлекаем исходный текст пользователя
    let sourceText = '';
    
    // Паттерн 1: После "Исходный текст:"
    const sourceMatch = message.match(/Исходный текст:\s*([\s\S]*)$/i);
    if (sourceMatch && sourceMatch[1]) {
      sourceText = sourceMatch[1].trim();
    }
    
    // Паттерн 2: Последний существенный абзац
    if (!sourceText || sourceText.length < 20) {
      const paragraphs = message.split(/\n\n+/).filter(p => p.trim().length > 20);
      if (paragraphs.length > 0) {
        // Берём последний абзац который выглядит как описание
        for (let i = paragraphs.length - 1; i >= 0; i--) {
          if (!paragraphs[i].includes('Проанализируй') && 
              !paragraphs[i].includes('Структура ответа') &&
              !paragraphs[i].startsWith('##')) {
            sourceText = paragraphs[i].trim();
            break;
          }
        }
      }
    }
    
    // Паттерн 3: Весь текст если ничего не найдено
    if (!sourceText || sourceText.length < 20) {
      sourceText = message.trim();
    }
    
    console.log(`[Fallback transcription_analyst] sourceText: "${sourceText.substring(0, 200)}..."`);
    
    // Анализируем исходный текст и генерируем конкретную идею
    const analysis = analyzeSourceIdea(sourceText);
    
    // Возвращаем НОВУЮ расширенную структуру
    return `## 💡 Название идеи
**${analysis.name}**

---

## 📋 Детальное описание идеи

### Суть продукта
${analysis.description}

### Контекст и предпосылки
${analysis.context}

### Ключевая ценность (Value Proposition)
${analysis.valueProposition}

### Основные функции
${analysis.functions.map((f, i) => `${i + 1}. ${f}`).join('\n')}

### Уникальное преимущество
${analysis.uniqueAdvantage}

---

## 👥 Типы пользователей и ролевая модель

### Сегменты пользователей (User Types)
| Тип | Описание | Мотивация | Боли |
|-----|----------|-----------|------|
${analysis.userTypes.map(u => `| ${u.type} | ${u.description} | ${u.motivation} | ${u.pains} |`).join('\n')}

### Ролевая модель сервиса
| Роль | Права | Обязанности | Ограничения |
|------|-------|-------------|-------------|
${analysis.roles.map(r => `| ${r.role} | ${r.rights} | ${r.duties} | ${r.restrictions} |`).join('\n')}

---

## 🎭 Use Cases пользователей

### UC-1: ${analysis.useCases[0]?.title || 'Основной сценарий'}
- **Актор:** ${analysis.useCases[0]?.actor || 'Пользователь'}
- **Предусловие:** ${analysis.useCases[0]?.precondition || 'Пользователь зарегистрирован'}
- **Основной поток:**
${analysis.useCases[0]?.steps?.map((s: string, i: number) => `  ${i + 1}. ${s}`).join('\n') || '  1. Пользователь открывает приложение\n  2. Выполняет действие\n  3. Получает результат'}
- **Результат:** ${analysis.useCases[0]?.result || 'Задача выполнена'}

### UC-2: ${analysis.useCases[1]?.title || 'Альтернативный сценарий'}
- **Актор:** ${analysis.useCases[1]?.actor || 'Пользователь'}
- **Предусловие:** ${analysis.useCases[1]?.precondition || 'Пользователь авторизован'}
- **Основной поток:**
${analysis.useCases[1]?.steps?.map((s: string, i: number) => `  ${i + 1}. ${s}`).join('\n') || '  1. Пользователь выбирает опцию\n  2. Подтверждает действие'}
- **Результат:** ${analysis.useCases[1]?.result || 'Действие завершено'}

### UC-3: ${analysis.useCases[2]?.title || 'Дополнительный сценарий'}
- **Актор:** ${analysis.useCases[2]?.actor || 'Пользователь'}
- **Предусловие:** ${analysis.useCases[2]?.precondition || 'Данные доступны'}
- **Основной поток:**
${analysis.useCases[2]?.steps?.map((s: string, i: number) => `  ${i + 1}. ${s}`).join('\n') || '  1. Пользователь просматривает данные\n  2. Изменяет при необходимости'}
- **Результат:** ${analysis.useCases[2]?.result || 'Данные обновлены'}

---

## ⚠️ Анализ рисков (от маркетолога-критика)

### 🔴 Критические риски
${analysis.criticalRisks.map((r, i) => `${i + 1}. **${r.title}** — ${r.description}
   - Влияние: ${r.impact}
   - Митигация: ${r.mitigation}`).join('\n\n') || '1. **Рыночный риск** — Требует custdev для валидации\n   - Влияние: Высокое\n   - Митигация: Провести интервью с целевой аудиторией'}

### 🟠 Значительные риски
${analysis.significantRisks.map((r, i) => `${i + 1}. **${r.title}** — ${r.description}
   - Влияние: ${r.impact}
   - Митигация: ${r.mitigation}`).join('\n\n') || '1. **Технический риск** — Требует оценки\n   - Влияние: Среднее\n   - Митигация: MVP для проверки гипотез'}

### 🟡 Умеренные риски
${analysis.moderateRisks.map((r, i) => `${i + 1}. **${r}**`).join('\n') || '1. **Требует дополнительного анализа**'}

---

## 🚧 Трудности реализации

### Технические сложности
${analysis.techDifficulties.map((d, i) => `- ${d}`).join('\n')}

### Рыночные барьеры
${analysis.marketBarriers.map((b, i) => `- ${b}`).join('\n')}

### Ресурсные ограничения
${analysis.resourceConstraints.map((c, i) => `- ${c}`).join('\n')}

---

## ✨ Рекомендации по оптимизации идеи

### Улучшения ценности
${analysis.valueImprovements.map((v, i) => `${i + 1}. ${v}`).join('\n')}

### Упрощение MVP
${analysis.mvpSimplifications.map((s, i) => `${i + 1}. ${s}`).join('\n')}

### Дифференциация от конкурентов
${analysis.differentiation.map((d, i) => `${i + 1}. ${d}`).join('\n')}

### Гипотезы для валидации
${analysis.hypotheses.map((h, i) => `${i + 1}. ${h}`).join('\n')}

---

## 📊 Итоговая оценка

| Критерий | Оценка (1-10) | Комментарий |
|----------|---------------|-------------|
| Актуальность | ${analysis.scores.relevance} | ${analysis.scores.relevanceComment} |
| Реализуемость | ${analysis.scores.feasibility} | ${analysis.scores.feasibilityComment} |
| Рыночный потенциал | ${analysis.scores.marketPotential} | ${analysis.scores.marketPotentialComment} |
| Конкурентоспособность | ${analysis.scores.competitiveness} | ${analysis.scores.competitivenessComment} |
| Уровень риска | ${analysis.scores.riskLevel} | ${analysis.scores.riskLevelComment} |

**Общий вывод:** ${analysis.overallConclusion}`;
  }

  // === МАРКЕТОЛОГ ===
  if (agentType === 'brand_marketer') {
    // Определяем тип продукта и подбираем релевантных конкурентов
    const productType = detectProductType(message + ' ' + idea.name + ' ' + idea.description);
    const competitors = generateCompetitors(productType, idea);
    
    return `## 🔍 Конкурентный анализ для "${idea.name}"

### Тип продукта: ${productType.name}

---

### 1. ПРЯМЫЕ КОНКУРЕНТЫ (3 продукта)

${competitors.direct.map((c, i) => `#### ${i + 1}. ${c.name} ${c.country ? `(${c.country})` : ''}
- **Сайт:** ${c.url}
- **Описание:** ${c.description}
- **Основные функции:** ${c.features}
- **Ценовая модель:** ${c.pricing}
- **Целевая аудитория:** ${c.targetAudience}

**SWOT-анализ:**
| Сильные стороны | Слабые стороны |
|-----------------|----------------|
| ${c.strengths.join('<br>')} | ${c.weaknesses.join('<br>')} |

| Возможности | Угрозы |
|-------------|--------|
| ${c.opportunities.join('<br>')} | ${c.threats.join('<br>')} |
`).join('\n')}

### 2. КОСВЕННЫЕ КОНКУРЕНТЫ (3 продукта)

${competitors.indirect.map((c, i) => `#### ${i + 1}. ${c.name}
- **Описание:** ${c.description}
- **Как решает проблему:** ${c.approach}
- **Пересечение с нашим продуктом:** ${c.overlap}
- **Ключевые отличия:** ${c.differentiation}
`).join('\n')}

### 3. СРАВНИТЕЛЬНАЯ ТАБЛИЦА

| Критерий | ${competitors.direct.map(c => c.name).join(' | ')} | ${idea.name} |
|----------|${competitors.direct.map(() => '----------|').join('')}----------|
| Функциональность | ${competitors.direct.map(c => c.functionalityScore).join(' | ')} | ⭐⭐⭐⭐ |
| Цена | ${competitors.direct.map(c => c.priceScore).join(' | ')} | ⭐⭐⭐⭐ |
| UX/UI | ${competitors.direct.map(c => c.uxScore).join(' | ')} | ⭐⭐⭐⭐⭐ |
| Поддержка | ${competitors.direct.map(c => c.supportScore).join(' | ')} | ⭐⭐⭐⭐ |

\`\`\`mermaid
mindmap
  root((Дифференциация ${idea.name}))
    Уникальные возможности
      ${idea.functions[0] || 'Инновационный подход'}
      ${idea.functions[1] || 'Современный стек'}
    Упрощение
      Интуитивный UI
      Быстрый старт
    Локализация
      Русский язык
      Российский рынок
    Цена
      Доступные тарифы
      Прозрачность
\`\`\`

### 4. АНАЛИЗ РЫНКА

**Размер рынка:** ${productType.marketSize}

**Тренды роста:**
${productType.trends.map(t => `- ${t}`).join('\n')}

**Барьеры входа:**
${productType.barriers.map(b => `- ${b}`).join('\n')}

### 5. ВОЗМОЖНОСТИ ДИФФЕРЕНЦИАЦИИ

На основе анализа конкурентов, ключевые возможности для дифференциации **${idea.name}**:

1. **Упрощение интерфейса** — большинство конкурентов имеют перегруженный UI
2. **Локализация для РФ** — многие зарубежные решения плохо работают с российскими платёжными системами
3. **Интеграции** — возможность интеграции с популярными российскими сервисами
4. **Ценовая доступность** — конкурентные цены для малого и среднего бизнеса
5. **Персонализация** — адаптация под конкретные потребности клиента

### 6. РЕКОМЕНДАЦИИ ПО ПОЗИЦИОНИРОВАНИЮ

${idea.name} должен позиционироваться как ${productType.positioning} с акцентом на:
- ${idea.functions[0] || 'Простоту использования'}
- Российский рынок и локальные особенности
- Соотношение цена/качество`;
  }

  // === CJM ===
  if (agentType === 'cjm_researcher') {
    return `## 🗺️ Customer Journey Map для "${idea.name}"

\`\`\`mermaid
journey
    title Путь пользователя ${idea.name}
    section Осознание
      Появление потребности: 3: Пользователь
      Поиск решения: 2: Пользователь
    section Рассмотрение
      Изучение продукта: 4: Пользователь
      Сравнение альтернатив: 3: Пользователь
    section Решение
      Регистрация: 3: Пользователь
      Первый опыт: 4: Пользователь
    section Использование
      ${idea.functions[0]?.substring(0, 25) || 'Основная функция'}: 5: Пользователь
      Расширение использования: 4: Пользователь
    section Лояльность
      Рекомендация: 5: Пользователь
\`\`\`

### Детальный анализ этапов

| Этап | Цель | Touchpoints | Эмоция | Боли |
|------|------|-------------|--------|------|
| Осознание | Понять потребность | Поиск, Реклама | 3/5 | Много вариантов |
| Рассмотрение | Выбрать решение | Сайт, Отзывы | 4/5 | Сложно сравнить |
| Решение | Начать использовать | Регистрация | 3/5 | Долгие формы |
| Использование | Получить ценность | Продукт | 5/5 | Обучение |
| Лояльность | Рекомендовать | Рассылки | 5/5 | Нет мотивации |

### Ключевые инсайты для "${idea.name}"
${idea.description}`;
  }

  // === IA / USERFLOW ===
  if (agentType === 'ia_architect') {
    // СНАЧАЛА проверяем на USERFLOW - более специфичные ключевые слова
    if (lowerMessage.includes('userflow') || lowerMessage.includes('пользовательск') || 
        lowerMessage.includes('сценар') || lowerMessage.includes('flowchart') ||
        lowerMessage.includes('happy path') || lowerMessage.includes('альтернативн') ||
        lowerMessage.includes('оптимальн') || lowerMessage.includes('основной userflow')) {
      return `## 🔄 Userflow сценарии для "${idea.name}"

### 1. 🎯 Основной Userflow (Happy Path)

\`\`\`mermaid
flowchart TD
    A[Старт] --> B[Открытие приложения]
    B --> C[Просмотр главного экрана]
    C --> D{Выбор действия}
    D --> E[${idea.functions[0]?.substring(0, 30) || 'Основная функция'}]
    E --> F[Получение результата]
    F --> G[Удовлетворение потребности]
    G --> H[Возврат или завершение]
    style A fill:#f5b942,color:#000
    style H fill:#22c55e,color:#fff
\`\`\`

**Описание:** Пользователь открывает приложение, выбирает нужную функцию и получает результат за минимальное количество шагов.

---

### 2. 🔄 Альтернативный Userflow

\`\`\`mermaid
flowchart TD
    A[Старт] --> B[Открытие приложения]
    B --> C[Поиск через поиск/фильтры]
    C --> D{Результаты найдены?}
    D -->|Да| E[Выбор из результатов]
    D -->|Нет| F[Расширение критериев]
    F --> C
    E --> G[Действие с выбранным]
    G --> H[Результат]
    style A fill:#f5b942,color:#000
    style H fill:#22c55e,color:#fff
\`\`\`

**Описание:** Пользователь использует поиск или фильтры для нахождения нужного объекта перед выполнением основного действия.

---

### 3. ⚡ Оптимальный Userflow (Оптимистичный)

\`\`\`mermaid
flowchart TD
    A[Старт] --> B[Быстрое действие с главного экрана]
    B --> C[Мгновенный результат]
    C --> D[Готово!]
    style A fill:#f5b942,color:#000
    style D fill:#22c55e,color:#fff
\`\`\`

**Описание:** Опытный пользователь или при идеальных условиях - действие выполняется в 1-2 клика через виджеты, шорткаты или избранное.

---

### 4. 📱 Описание ключевых экранов

| Экран | Цель | Ключевые элементы | Действия пользователя |
|-------|------|-------------------|----------------------|
| **Главный** | Быстрый доступ к функциям | Кнопки действий, виджеты, избранное | Выбор функции, навигация |
| **${idea.functions[0]?.substring(0, 20) || 'Функция 1'}** | Выполнение основной задачи | Форма ввода, результаты | Ввод данных, подтверждение |
| **Результаты** | Просмотр результата | Детали, действия, шеринг | Сохранение, повтор, выход |
| **Профиль** | Управление аккаунтом | Настройки, история | Редактирование, выход |`;
    }
    
    // ПОТОМ проверяем на IA
    if (lowerMessage.includes('таксономи') || lowerMessage.includes('сущност') || lowerMessage.includes('информационн')) {
      return `## 🏗️ Информационная архитектура для "${idea.name}"

### Структура продукта

\`\`\`mermaid
mindmap
  root((${idea.name}))
    Главная
      Дашборд
      Быстрые действия
    ${idea.functions[0]?.substring(0, 20) || 'Функции'}
      Основные
      Дополнительные
    Профиль
      Настройки
      История
\`\`\`

### Таксономия сущностей

\`\`\`mermaid
erDiagram
    USER ||--o{ ITEM : creates
    USER ||--o{ ACTION : performs
    USER {
        string id PK
        string email
        string name
    }
    ITEM {
        string id PK
        string title
        string status
    }
\`\`\`

### Навигационная структура
- Главная → Дашборд
- ${idea.functions[0]?.substring(0, 30) || 'Функции'} → Детали
- Профиль → Настройки`;
    }
    
    // Default - IA без специфичных ключевых слов
    return `## 🏗️ Информационная архитектура для "${idea.name}"

### Структура продукта

\`\`\`mermaid
mindmap
  root((${idea.name}))
    Главная
      Дашборд
      Быстрые действия
    ${idea.functions[0]?.substring(0, 20) || 'Функции'}
      Основные
      Дополнительные
    Профиль
      Настройки
      История
\`\`\`

### Таксономия сущностей

\`\`\`mermaid
erDiagram
    USER ||--o{ ITEM : creates
    USER ||--o{ ACTION : performs
    USER {
        string id PK
        string email
        string name
    }
    ITEM {
        string id PK
        string title
        string status
    }
\`\`\`

### Навигационная структура
- Главная → Дашборд
- ${idea.functions[0]?.substring(0, 30) || 'Функции'} → Детали
- Профиль → Настройки`;
  }


  // === ПРОТОТИП ===
  if (agentType === 'prototyper') {
    // Detect product type for better defaults
    const productType = detectProductType(message + ' ' + idea.name + ' ' + idea.description);
    
    // Clean product name from markdown
    const productName = idea.name.replace(/\*\*/g, '').replace(/["«»]/g, '').trim();
    
    // Smart function extraction with null checks
    let func1 = idea.functions[0] || 'Основная функция';
    let func2 = idea.functions[1] || 'Дополнительные возможности';
    let func3 = idea.functions[2] || 'Настройки';
    
    // Product-type specific defaults
    if (!func1 || func1 === 'Основная функция продукта') {
      const defaultFunctions: Record<string, string[]> = {
        booking: ['Онлайн-запись на услугу', 'Календарь свободных слотов', 'SMS-напоминания'],
        ats: ['Виртуальная АТС', 'Запись звонков', 'Аналитика'],
        dashboard: ['Виджеты и графики', 'Экспорт отчётов', 'Real-time данные'],
        crm: ['Управление сделками', 'Контакт-профили', 'Автоматизация'],
        ecommerce: ['Каталог товаров', 'Корзина и оплата', 'Отслеживание заказа'],
        taxi: ['Заказ поездки', 'Отслеживание машины', 'Оплата в приложении'],
        messenger: ['Чаты и звонки', 'Групповые беседы', 'Шаринг файлов'],
        task: ['Kanban-доска', 'Задачи и дедлайны', 'Командная работа'],
        hr: ['Вакансии и отклики', 'Кандидаты', 'Онбординг'],
        fintech: ['Платежи и переводы', 'Баланс и выписки', 'Бюджетирование'],
        education: ['Курсы и уроки', 'Прогресс обучения', 'Сертификаты'],
        health: ['Запись к врачу', 'Медицинская карта', 'Телемедицина'],
        logistics: ['Отслеживание груза', 'Маршруты доставки', 'Документы'],
        default: ['Основная функция', 'Дополнительные возможности', 'Настройки']
      };
      
      const funcs = defaultFunctions[productType.id] || defaultFunctions.default;
      func1 = funcs[0];
      func2 = funcs[1];
      func3 = funcs[2];
    }
    
    // Extract value proposition from description
    const valueProp = idea.description.length > 100 
      ? idea.description.substring(0, 100) + '...'
      : idea.description || 'Инновационное решение для вашего бизнеса';
    
    console.log(`[Fallback Prototype] Product: "${productName}", Type: ${productType.id}, Functions: [${func1}, ${func2}, ${func3}]`);
    
    return `## 🎨 Интерактивный прототип "${productName}"

\`\`\`html
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>${productName}</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #000; color: #fff; min-height: 100vh; overflow-x: hidden; }
        
        /* Screen system */
        .screen { display: none; min-height: 100vh; position: relative; }
        .screen.active { display: flex; flex-direction: column; }
        
        /* Animations */
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes float { 0%, 100% { transform: translateY(0px); } 50% { transform: translateY(-8px); } }
        @keyframes glow { 0%, 100% { box-shadow: 0 0 20px rgba(250, 204, 21, 0.3); } 50% { box-shadow: 0 0 35px rgba(250, 204, 21, 0.6); } }
        @keyframes shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
        @keyframes scanline { 0% { top: -10%; } 100% { top: 110%; } }
        @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.05); } }
        
        .fade-in { animation: fadeIn 0.4s ease-out; }
        .animate-float { animation: float 3s ease-in-out infinite; }
        .animate-glow { animation: glow 2s ease-in-out infinite; }
        .animate-pulse { animation: pulse 2s ease-in-out infinite; }
        
        /* Colors */
        :root {
            --bg: #000000;
            --bg-card: #0A0A0A;
            --bg-elevated: #141414;
            --border: #1A1A1A;
            --text: #FFFFFF;
            --text-secondary: #A3A3A3;
            --text-muted: #737373;
            --accent: #FACC15;
            --success: #22C55E;
            --error: #EF4444;
        }
        
        .mono { font-family: 'JetBrains Mono', monospace; }
        .gradient-text { background: linear-gradient(90deg, #FACC15, #FEF08A, #FACC15); background-size: 200% auto; -webkit-background-clip: text; -webkit-text-fill-color: transparent; animation: shimmer 3s linear infinite; }
        
        /* Grid background */
        .grid-bg { background-image: linear-gradient(rgba(250, 204, 21, 0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(250, 204, 21, 0.03) 1px, transparent 1px); background-size: 50px 50px; }
        
        /* Scanline effect */
        .scanline { position: fixed; left: 0; right: 0; height: 4px; background: linear-gradient(to bottom, transparent, rgba(250, 204, 21, 0.15), transparent); animation: scanline 6s linear infinite; pointer-events: none; z-index: 9999; }
        
        /* Buttons */
        .btn-primary { 
            padding: 14px 32px; border-radius: 12px; border: none; 
            background: var(--accent); color: #000; font-weight: 700; font-size: 16px; 
            cursor: pointer; transition: all 0.3s;
        }
        .btn-primary:hover { transform: scale(1.02); }
        
        .btn-secondary { 
            padding: 14px 32px; border-radius: 12px; border: 1px solid var(--border); 
            background: transparent; color: var(--text); font-weight: 600; font-size: 16px; 
            cursor: pointer; transition: all 0.3s;
        }
        .btn-secondary:hover { border-color: var(--accent); }
        
        /* Cards */
        .card {
            background: var(--bg-elevated);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 20px;
            transition: all 0.3s;
            position: relative;
        }
        .card:hover { border-color: var(--accent); }
        .card::before { content: ''; position: absolute; inset: -1px; background: linear-gradient(45deg, var(--accent), transparent, var(--accent)); border-radius: inherit; z-index: -1; opacity: 0; transition: opacity 0.3s; }
        .card:hover::before { opacity: 1; }
        
        /* Input */
        .input {
            width: 100%; padding: 14px 16px; border-radius: 12px;
            border: 1px solid var(--border); background: var(--bg-card);
            color: var(--text); font-size: 16px; font-family: inherit;
            transition: all 0.2s;
        }
        .input:focus { outline: none; border-color: var(--accent); }
        .input::placeholder { color: var(--text-muted); }
        
        /* SPLASH SCREEN */
        #splash { align-items: center; justify-content: center; text-align: center; padding: 40px; }
        .logo-large { 
            width: 100px; height: 100px; border-radius: 24px; 
            background: linear-gradient(135deg, var(--accent), #FDE047);
            display: flex; align-items: center; justify-content: center; 
            font-size: 40px; font-weight: 900; color: #000; 
            margin: 0 auto 32px;
        }
        .splash-title { font-size: 36px; font-weight: 900; margin-bottom: 16px; letter-spacing: -1px; }
        .splash-desc { color: var(--text-secondary); max-width: 300px; margin: 0 auto 40px; line-height: 1.6; }
        
        /* ONBOARDING */
        #onboarding { padding: 60px 24px 40px; }
        .progress-bar { width: 100%; height: 4px; background: var(--border); border-radius: 2px; margin-bottom: 48px; }
        .progress-fill { height: 100%; background: var(--accent); border-radius: 2px; transition: width 0.3s; }
        .step { text-align: center; padding: 40px 0; }
        .step-icon { font-size: 64px; margin-bottom: 24px; }
        .step-title { font-size: 24px; font-weight: 800; margin-bottom: 12px; }
        .step-desc { color: var(--text-secondary); }
        .onboarding-buttons { display: flex; gap: 12px; margin-top: auto; padding-top: 40px; }
        
        /* MAIN / DASHBOARD */
        #main { background: var(--bg); }
        
        .header { 
            position: fixed; top: 0; left: 0; right: 0; 
            padding: 16px 20px; 
            background: rgba(0,0,0,0.95); backdrop-filter: blur(20px); 
            z-index: 100; border-bottom: 1px solid var(--border); 
            display: flex; justify-content: space-between; align-items: center;
        }
        .header-logo { display: flex; align-items: center; gap: 12px; }
        .header-logo-icon { 
            width: 36px; height: 36px; border-radius: 10px; 
            background: var(--accent); 
            display: flex; align-items: center; justify-content: center; 
            font-weight: 900; color: #000; font-size: 14px;
        }
        .header-title { font-weight: 700; font-size: 18px; }
        .header-action { 
            width: 40px; height: 40px; border-radius: 50%; 
            background: var(--bg-elevated); border: none;
            display: flex; align-items: center; justify-content: center; 
            cursor: pointer; font-size: 18px;
        }
        
        .main-content { flex: 1; padding: 80px 20px 100px; overflow-y: auto; }
        
        .welcome-section { margin-bottom: 24px; }
        .welcome-title { font-size: 26px; font-weight: 800; margin-bottom: 4px; }
        .welcome-subtitle { color: var(--text-secondary); font-size: 14px; }
        
        .stats-row { display: flex; gap: 12px; margin-bottom: 24px; overflow-x: auto; padding-bottom: 8px; }
        .stat-card { 
            flex: 1; min-width: 100px;
            background: var(--bg-elevated); border: 1px solid var(--border);
            border-radius: 12px; padding: 16px; text-align: center;
        }
        .stat-value { font-size: 24px; font-weight: 700; color: var(--accent); }
        .stat-label { font-size: 12px; color: var(--text-muted); margin-top: 4px; }
        
        .quick-actions { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-bottom: 24px; }
        .action-card { 
            background: var(--bg-elevated); border: 1px solid var(--border);
            border-radius: 16px; padding: 20px; text-align: center; 
            cursor: pointer; transition: all 0.3s;
        }
        .action-card:hover { border-color: var(--accent); transform: translateY(-2px); }
        .action-icon { font-size: 32px; margin-bottom: 8px; }
        .action-title { font-weight: 600; font-size: 13px; color: var(--text-secondary); }
        
        .section-title { font-size: 16px; font-weight: 700; margin-bottom: 12px; display: flex; align-items: center; gap: 8px; }
        .section-title span { color: var(--accent); }
        
        .bottom-nav { 
            position: fixed; bottom: 0; left: 0; right: 0; 
            background: rgba(0,0,0,0.95); backdrop-filter: blur(20px); 
            border-top: 1px solid var(--border); 
            display: flex; justify-content: space-around; padding: 12px 0;
        }
        .nav-item { 
            display: flex; flex-direction: column; align-items: center; gap: 4px; 
            color: var(--text-muted); cursor: pointer; 
            padding: 8px 16px; border-radius: 12px; 
            transition: all 0.2s; border: none; background: none;
            font-family: inherit; font-size: inherit;
        }
        .nav-item.active { color: var(--accent); }
        .nav-item:hover { background: var(--bg-elevated); }
        .nav-icon { font-size: 20px; }
        .nav-label { font-size: 11px; font-weight: 500; }
        
        /* ACTION SCREEN */
        #action { background: var(--bg); }
        .back-header { 
            position: fixed; top: 0; left: 0; right: 0; 
            padding: 16px 20px; 
            background: rgba(0,0,0,0.95); backdrop-filter: blur(20px); 
            z-index: 100; border-bottom: 1px solid var(--border); 
            display: flex; align-items: center; gap: 16px;
        }
        .back-btn { 
            width: 40px; height: 40px; border-radius: 50%; 
            background: var(--bg-elevated); border: none; 
            color: var(--text); cursor: pointer; 
            display: flex; align-items: center; justify-content: center; font-size: 18px;
        }
        .screen-title { font-weight: 700; font-size: 18px; }
        .action-content { flex: 1; padding: 80px 20px 20px; }
        .form-group { margin-bottom: 16px; }
        .form-label { display: block; margin-bottom: 8px; font-weight: 500; font-size: 14px; color: var(--text-secondary); }
        
        /* RESULT SCREEN */
        #result { align-items: center; justify-content: center; text-align: center; padding: 40px; }
        .result-icon { 
            width: 100px; height: 100px; border-radius: 50%; 
            background: var(--success); 
            display: flex; align-items: center; justify-content: center; 
            font-size: 48px; margin: 0 auto 32px;
        }
        .result-title { font-size: 28px; font-weight: 800; margin-bottom: 12px; }
        .result-message { color: var(--text-secondary); margin-bottom: 32px; }
        .result-buttons { display: flex; flex-direction: column; gap: 12px; width: 100%; max-width: 280px; }
        
        /* PROFILE SCREEN */
        #profile { background: var(--bg); }
        .profile-header { text-align: center; padding: 80px 20px 24px; border-bottom: 1px solid var(--border); }
        .profile-avatar { 
            width: 80px; height: 80px; border-radius: 50%; 
            background: linear-gradient(135deg, var(--accent), #FDE047); 
            margin: 0 auto 16px; 
            display: flex; align-items: center; justify-content: center; font-size: 32px;
        }
        .profile-name { font-size: 20px; font-weight: 700; margin-bottom: 4px; }
        .profile-email { color: var(--text-muted); font-size: 14px; }
        .settings-list { padding: 20px; }
        .settings-item { 
            display: flex; align-items: center; gap: 16px; 
            padding: 16px; 
            background: var(--bg-elevated); border: 1px solid var(--border);
            border-radius: 12px; margin-bottom: 12px; 
            cursor: pointer; transition: all 0.2s;
        }
        .settings-item:hover { border-color: var(--accent); }
        .settings-icon { font-size: 24px; }
        .settings-text { flex: 1; font-weight: 500; }
        .settings-arrow { color: var(--text-muted); }
        
        /* TOAST */
        .toast { 
            position: fixed; bottom: 100px; left: 20px; right: 20px; 
            background: var(--bg-elevated); border: 1px solid var(--success);
            border-radius: 12px; padding: 16px; 
            display: flex; align-items: center; gap: 12px; 
            transform: translateY(200%); transition: transform 0.3s; z-index: 200;
        }
        .toast.show { transform: translateY(0); }
        .toast-icon { 
            width: 32px; height: 32px; border-radius: 50%; 
            background: var(--success); 
            display: flex; align-items: center; justify-content: center;
        }
        .toast-text { flex: 1; }
        .toast-title { font-weight: 600; font-size: 14px; }
        .toast-message { font-size: 12px; color: var(--text-secondary); }
    </style>
</head>
<body>
    <div class="scanline"></div>
    
    <!-- SPLASH SCREEN -->
    <div id="splash" class="screen active grid-bg">
        <div class="fade-in">
            <div class="logo-large animate-float">${productName.substring(0, 2).toUpperCase()}</div>
            <h1 class="splash-title">${productName}</h1>
            <p class="splash-desc">${valueProp}</p>
            <button class="btn-primary animate-glow" onclick="showScreen('onboarding')">Начать</button>
        </div>
    </div>

    <!-- ONBOARDING -->
    <div id="onboarding" class="screen grid-bg">
        <div class="progress-bar"><div class="progress-fill" id="progress" style="width: 33%"></div></div>
        
        <div id="step1" class="step fade-in">
            <div class="step-icon">✨</div>
            <h2 class="step-title">${func1.substring(0, 40)}</h2>
            <p class="step-desc">Ключевая возможность продукта</p>
        </div>
        
        <div id="step2" class="step" style="display: none;">
            <div class="step-icon">🎯</div>
            <h2 class="step-title">${func2.substring(0, 40)}</h2>
            <p class="step-desc">Дополнительные функции</p>
        </div>
        
        <div id="step3" class="step" style="display: none;">
            <div class="step-icon">🚀</div>
            <h2 class="step-title">Готовы начать?</h2>
            <p class="step-desc">${func3.substring(0, 40)}</p>
        </div>
        
        <div class="onboarding-buttons">
            <button class="btn-secondary" id="skipBtn" onclick="showScreen('main')">Пропустить</button>
            <button class="btn-primary animate-glow" id="nextBtn" onclick="nextStep()">Далее</button>
        </div>
    </div>

    <!-- MAIN / DASHBOARD -->
    <div id="main" class="screen">
        <header class="header">
            <div class="header-logo">
                <div class="header-logo-icon">${productName.substring(0, 2).toUpperCase()}</div>
                <span class="header-title">${productName.split(' ')[0]}</span>
            </div>
            <button class="header-action" onclick="showScreen('profile')">👤</button>
        </header>
        
        <main class="main-content">
            <section class="welcome-section fade-in">
                <h2 class="welcome-title">Добро пожаловать!</h2>
                <p class="welcome-subtitle">${valueProp.substring(0, 60)}</p>
            </section>
            
            <div class="stats-row">
                <div class="stat-card animate-float" style="animation-delay: 0s;">
                    <div class="stat-value mono">24</div>
                    <div class="stat-label">Сегодня</div>
                </div>
                <div class="stat-card animate-float" style="animation-delay: 0.1s;">
                    <div class="stat-value mono">+12%</div>
                    <div class="stat-label">Рост</div>
                </div>
                <div class="stat-card animate-float" style="animation-delay: 0.2s;">
                    <div class="stat-value mono">5</div>
                    <div class="stat-label">В процессе</div>
                </div>
            </div>
            
            <section class="quick-actions">
                <div class="action-card" onclick="showScreen('action')">
                    <div class="action-icon">⚡</div>
                    <div class="action-title">${func1.substring(0, 20)}</div>
                </div>
                <div class="action-card">
                    <div class="action-icon">📊</div>
                    <div class="action-title">Статистика</div>
                </div>
                <div class="action-card">
                    <div class="action-icon">📅</div>
                    <div class="action-title">История</div>
                </div>
                <div class="action-card" onclick="showScreen('profile')">
                    <div class="action-icon">⚙️</div>
                    <div class="action-title">Настройки</div>
                </div>
            </section>
            
            <section>
                <h3 class="section-title">Возможности <span>→</span></h3>
                <div class="card" style="margin-bottom: 12px;">
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <div style="font-size: 28px;">🎯</div>
                        <div style="flex: 1;">
                            <div style="font-weight: 600;">${func1.substring(0, 30)}</div>
                            <div style="font-size: 13px; color: var(--text-muted);">Основная функция</div>
                        </div>
                        <span style="color: var(--text-muted);">→</span>
                    </div>
                </div>
                <div class="card" style="margin-bottom: 12px;">
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <div style="font-size: 28px;">🔒</div>
                        <div style="flex: 1;">
                            <div style="font-weight: 600;">${func2.substring(0, 30)}</div>
                            <div style="font-size: 13px; color: var(--text-muted);">Безопасность</div>
                        </div>
                        <span style="color: var(--text-muted);">→</span>
                    </div>
                </div>
                <div class="card">
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <div style="font-size: 28px;">📈</div>
                        <div style="flex: 1;">
                            <div style="font-weight: 600;">${func3.substring(0, 30)}</div>
                            <div style="font-size: 13px; color: var(--text-muted);">Аналитика</div>
                        </div>
                        <span style="color: var(--text-muted);">→</span>
                    </div>
                </div>
            </section>
        </main>
        
        <nav class="bottom-nav">
            <button class="nav-item active" onclick="showScreen('main')">
                <span class="nav-icon">🏠</span>
                <span class="nav-label">Главная</span>
            </button>
            <button class="nav-item" onclick="showScreen('action')">
                <span class="nav-icon">➕</span>
                <span class="nav-label">Действие</span>
            </button>
            <button class="nav-item" onclick="showScreen('profile')">
                <span class="nav-icon">👤</span>
                <span class="nav-label">Профиль</span>
            </button>
        </nav>
    </div>

    <!-- ACTION SCREEN -->
    <div id="action" class="screen">
        <header class="back-header">
            <button class="back-btn" onclick="showScreen('main')">←</button>
            <span class="screen-title">${func1.substring(0, 30)}</span>
        </header>
        
        <main class="action-content">
            <div class="card fade-in">
                <h3 style="font-size: 20px; font-weight: 700; margin-bottom: 24px;">Выполнить действие</h3>
                
                <div class="form-group">
                    <label class="form-label">Название</label>
                    <input type="text" class="input" placeholder="Введите данные">
                </div>
                
                <div class="form-group">
                    <label class="form-label">Категория</label>
                    <select class="input">
                        <option>Категория 1</option>
                        <option>Категория 2</option>
                        <option>Категория 3</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="form-label">Описание</label>
                    <textarea class="input" rows="3" placeholder="Дополнительная информация"></textarea>
                </div>
                
                <button class="btn-primary animate-glow" style="width: 100%; margin-top: 16px;" onclick="showScreen('result')">Выполнить</button>
            </div>
        </main>
    </div>

    <!-- RESULT SCREEN -->
    <div id="result" class="screen grid-bg">
        <div class="fade-in">
            <div class="result-icon animate-pulse">✓</div>
            <h2 class="result-title">Успешно выполнено!</h2>
            <p class="result-message">Действие "${func1.substring(0, 20)}" успешно завершено.</p>
            <div class="result-buttons">
                <button class="btn-primary animate-glow" onclick="showScreen('main')">На главную</button>
                <button class="btn-secondary" onclick="showScreen('action')">Новое действие</button>
            </div>
        </div>
    </div>

    <!-- PROFILE SCREEN -->
    <div id="profile" class="screen">
        <header class="back-header">
            <button class="back-btn" onclick="showScreen('main')">←</button>
            <span class="screen-title">Профиль</span>
        </header>
        
        <div class="profile-header">
            <div class="profile-avatar">👤</div>
            <div class="profile-name">Пользователь</div>
            <div class="profile-email">user@example.com</div>
        </div>
        
        <div class="settings-list">
            <div class="settings-item" onclick="showToast('Настройки сохранены')">
                <span class="settings-icon">⚙️</span>
                <span class="settings-text">Настройки аккаунта</span>
                <span class="settings-arrow">→</span>
            </div>
            <div class="settings-item" onclick="showToast('Уведомления обновлены')">
                <span class="settings-icon">🔔</span>
                <span class="settings-text">Уведомления</span>
                <span class="settings-arrow">→</span>
            </div>
            <div class="settings-item">
                <span class="settings-icon">🔒</span>
                <span class="settings-text">Безопасность</span>
                <span class="settings-arrow">→</span>
            </div>
            <div class="settings-item">
                <span class="settings-icon">❓</span>
                <span class="settings-text">Помощь</span>
                <span class="settings-arrow">→</span>
            </div>
            <div class="settings-item" onclick="showScreen('splash')" style="border-color: var(--error);">
                <span class="settings-icon">🚪</span>
                <span class="settings-text" style="color: var(--error);">Выйти</span>
                <span class="settings-arrow">→</span>
            </div>
        </div>
    </div>

    <!-- TOAST -->
    <div id="toast" class="toast">
        <div class="toast-icon">✓</div>
        <div class="toast-text">
            <div class="toast-title">Успешно!</div>
            <div class="toast-message" id="toastMessage">Действие выполнено</div>
        </div>
    </div>

    <script>
        let currentStep = 1;
        const totalSteps = 3;
        
        function showScreen(id) {
            document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
            const screen = document.getElementById(id);
            if (screen) {
                screen.classList.add('active');
                window.scrollTo(0, 0);
            }
        }
        
        function nextStep() {
            if (currentStep < totalSteps) {
                document.getElementById('step' + currentStep).style.display = 'none';
                currentStep++;
                const nextStepEl = document.getElementById('step' + currentStep);
                nextStepEl.style.display = 'block';
                nextStepEl.classList.add('fade-in');
                document.getElementById('progress').style.width = (currentStep / totalSteps * 100) + '%';
                
                if (currentStep === totalSteps) {
                    document.getElementById('nextBtn').textContent = 'Начать работу';
                    document.getElementById('nextBtn').onclick = () => showScreen('main');
                    document.getElementById('skipBtn').style.display = 'none';
                }
            }
        }
        
        function showToast(message) {
            const toast = document.getElementById('toast');
            document.getElementById('toastMessage').textContent = message;
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 3000);
        }
    </script>
</body>
</html>
\`\`\``;
  }
  // === ТЕСТИРОВАНИЕ ===
  if (agentType === 'task_architect') {
    if (lowerMessage.includes('приглаш') || lowerMessage.includes('скрипт')) {
      return `## 📧 Скрипт приглашения для "${idea.name}"

### Email-приглашение

**Тема:** Приглашение на тестирование ${idea.name}

Здравствуйте!

Приглашаем вас принять участие в тестировании ${idea.name} — ${idea.description.substring(0, 100)}.

**Что тестируем:** ${idea.name}
**Формат:** Онлайн (Zoom)
**Длительность:** 30-45 минут
**Вознаграждение:** [указать]

**Профиль участника:**
- Интерес к теме: ${idea.description.substring(0, 50)}
- Опыт использования похожих продуктов

Записаться: [ссылка]

---

### Telegram/WhatsApp

🧪 Приглашение на тестирование!

Продукт: ${idea.name}
📝 ${idea.description.substring(0, 80)}
⏱️ Время: 30-45 мин
🎁 Благодарность: [указать]

Записаться: [ссылка]`;
    }
    
    if (lowerMessage.includes('гайдлайн') || lowerMessage.includes('руководство')) {
      return `## 📖 Гайдлайн юзабилити-тестирования для "${idea.name}"

### Структура сессии (45 минут)

| Этап | Время | Действие |
|------|-------|----------|
| Приветствие | 3 мин | Знакомство |
| Введение | 5 мин | Объяснение формата |
| Задачи | 25 мин | Тестирование |
| Интервью | 10 мин | Вопросы |
| Завершение | 2 мин | Благодарность |

### Задачи для тестирования

1. **Ознакомление:** Посмотрите главную страницу, что это за продукт?
2. **Основная задача:** ${idea.functions[0] || 'Используйте основную функцию'}
3. **Поиск функции:** Найдите ${idea.functions[1] || 'дополнительную функцию'}
4. **Завершение:** Выполните целевое действие
5. **Обратная связь:** Оцените удобство

### Вопросы пост-тест

1. Первое впечатление?
2. Что было сложно?
3. Что понравилось?
4. Что изменить?
5. Оценка 1-10`;
    }
    
    return `## 📊 Продуктовые метрики для "${idea.name}"

### 1. Северная метрика
Количество успешных ${idea.functions[0]?.toLowerCase() || 'целевых действий'}

### 2. Acquisition
- Визиты на сайт
- Регистрации
- Конверсия в регистрацию

### 3. Activation
- Time to first value
- Первое успешное действие
- Feature adoption

### 4. Retention
- Day 1/7/30 retention
- DAU/MAU
- Возвращаемость

### 5. Revenue (если применимо)
- ARPU
- LTV
- Conversion to paid

### Рекомендации по отслеживанию
- Настроить цели в Яндекс.Метрике
- Логировать: ${idea.functions.slice(0, 3).join(', ') || 'ключевые действия'}
- Создать дашборд мониторинга`;
  }

  return `Обработка запроса. Попробуйте ещё раз.`;
}
